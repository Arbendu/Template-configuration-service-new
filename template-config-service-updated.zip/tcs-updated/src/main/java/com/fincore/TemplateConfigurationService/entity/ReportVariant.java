package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "RB_REPORT_VARIANT")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportVariant {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "VARIANT_ID")
    private Long variantId;

    @Column(name = "TEMPLATE_ID", length = 100)
    private String templateId;

    @Column(name = "VARIANT_CODE", length = 100)
    private String variantCode;

    @Column(name = "VARIANT_NAME", length = 200)
    private String variantName;

    @Column(name = "DESCRIPTION", length = 500)
    private String description;

    @Column(name = "STATUS", length = 30)
    private String status;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "UPDATED_BY", length = 50)
    private String updatedBy;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    //  Mapped FilterRule entity
    @OneToMany(mappedBy = "reportVariant", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FilterRule> filterRules;

    //  Mapped VariantParamDef entity
    @OneToMany(mappedBy = "reportVariant", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<VariantParamDef> params;
}