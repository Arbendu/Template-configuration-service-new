package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "RB_ALLOWED_COLUMNS")
public class AllowedColumns {

    @Id
    @Column(name = "ID")
    private Long id;

    @Column(name = "COLUMN_NAME")
    private String columnName;

    @Column(name = "LABEL")
    private String label;

    @Column(name = "DATA_TYPE")
    private String dataType;

    @Column(name = "SELECTABLE")
    private String selectable;

    @Column(name = "FILTERABLE")
    private String filterable;

    @Column(name = "AGG_FUNCS")
    private String aggFuncs;

    @Column(name = "ACTIVE")
    private String active;

    @ManyToOne
    @JoinColumn(name = "TABLE_ID")
    private AllowedTables table;
}