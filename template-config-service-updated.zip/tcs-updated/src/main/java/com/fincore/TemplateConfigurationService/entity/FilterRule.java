package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "RB_FILTER_RULE")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FilterRule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "RULE_ID")
    private Long ruleId;

//    @Column(name = "VARIANT_ID")
//    private Long variantId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VARIANT_ID", nullable = false)
    private ReportVariant reportVariant;            // This is the mappedBy target

    @Column(name = "SCOPE_TYPE", length = 50)
    private String scopeType;

    @Column(name = "SCOPE_VALUE", length = 200)
    private String scopeValue;

    @Column(name = "PARAM_NAME", length = 100)
    private String paramName;

    @Column(name = "DB_COLUMN", length = 100)
    private String dbColumn;

    @Column(name = "OPERATOR", length = 20)
    private String operator;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;
}