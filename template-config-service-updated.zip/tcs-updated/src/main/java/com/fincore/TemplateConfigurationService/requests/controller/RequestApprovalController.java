package com.fincore.TemplateConfigurationService.requests.controller;

import com.fincore.TemplateConfigurationService.requests.dto.ApprovedRequestDto;
import com.fincore.TemplateConfigurationService.requests.dto.RequestProcessingResultDto;
import com.fincore.TemplateConfigurationService.requests.dto.RequestValidationDto;
import com.fincore.TemplateConfigurationService.requests.service.RequestApprovalService;
import com.fincore.TemplateConfigurationService.requests.service.RequestValidationService;
import com.fincore.TemplateConfigurationService.response.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * REST controller for the {@code /api/requests} sub-package.
 *
 * <h2>Endpoints</h2>
 * <ul>
 *   <li>{@code POST /api/requests/process-approval} – Called by common-request-service
 *       when a checker approves a template request. Executes the ADD / UPDATE / DELETE
 *       operation on the live template data.</li>
 *   <li>{@code POST /api/requests/validate} – Called by the maker UI before submitting
 *       a request to CRS. Runs all validation gates without persisting anything.
 *       Returns {@code 200 OK} on success or {@code 400 Bad Request} with an error
 *       message on failure.</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/requests")
@RequiredArgsConstructor
public class RequestApprovalController {

    private final RequestApprovalService  approvalService;
    private final RequestValidationService validationService;

    // =========================================================================
    // POST /api/requests/process-approval
    // Called by CRS after a checker approves a template change request.
    // =========================================================================

    /**
     * Processes an approved template request.
     *
     * <p>Payload must contain the serialised {@code TemplatePayload} JSON
     * as it was stored in the {@code COMMON_REQ.PAYLOAD} column in CRS.</p>
     *
     * @param dto   the approved request details
     * @param httpReq the raw HTTP request (used for the audit path in the response)
     * @return {@code 200 OK} with processing result, or an error body on failure
     */
    @PostMapping("/process-approval")
    public ResponseEntity<ApiResponse> processApproval(
            @Valid @RequestBody ApprovedRequestDto dto,
            HttpServletRequest httpReq) {

        log.info("Received process-approval: requestId={} changeType={} creatorId={}",
                dto.getRequestId(), dto.getChangeType(), dto.getCreatorId());

        RequestProcessingResultDto result = approvalService.processApproval(dto);

        ApiResponse response = ApiResponse.builder()
                .message(result.getMessage())
                .status("SUCCESS")
                .data(result)
                .timestamp(LocalDateTime.now())
                .path(httpReq.getRequestURI())
                .build();

        return ResponseEntity.ok(response);
    }

    // =========================================================================
    // POST /api/requests/validate
    // Called by the maker UI before submitting a request to CRS.
    // =========================================================================

    /**
     * Validates a template payload without persisting any changes.
     *
     * <p>Returns {@code 200 OK} with a success body when the template passes
     * all validation gates. Returns {@code 400 Bad Request} with the first
     * violation message if any gate fails.</p>
     *
     * @param dto     validation input including changeType and the template payload
     * @param httpReq raw HTTP request
     * @return validation outcome
     */
    @PostMapping("/validate")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<ApiResponse> validateTemplate(
            @Valid @RequestBody RequestValidationDto dto,
            HttpServletRequest httpReq) {

        log.info("Received template validation request: changeType={} reportId={}",
                dto.getChangeType(),
                dto.getPayload() != null && dto.getPayload().getTemplate() != null
                        ? dto.getPayload().getTemplate().getReportMeta().getReportId()
                        : "unknown");

        // Throws BadRequestException on first violation – caught by GlobalExceptionHandler
        validationService.validate(dto);

        ApiResponse response = ApiResponse.builder()
                .message("Template payload is valid. Safe to submit for approval.")
                .status("SUCCESS")
                .timestamp(LocalDateTime.now())
                .path(httpReq.getRequestURI())
                .build();

        return ResponseEntity.ok(response);
    }
}
