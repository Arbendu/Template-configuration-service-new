package com.fincore.TemplateConfigurationService.dto;

import lombok.*;

import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateDiffResponseDto {

    private TemplatePayload oldTemplate;
    private TemplatePayload newTemplate;

    /**
     * cellId -> (fieldName -> old/new value)
     */
    private Map<String, Map<String, ValueDiff>> cellDiffs;

    /**
     * columnId -> (fieldName -> old/new value)
     */
    private Map<String, Map<String, ValueDiff>> columnDiffs;

    private Map<String, Map<String, ValueDiff>> variantDiffs;

    private Map<String, Map<String, ValueDiff>> globalParamDiffs;
}