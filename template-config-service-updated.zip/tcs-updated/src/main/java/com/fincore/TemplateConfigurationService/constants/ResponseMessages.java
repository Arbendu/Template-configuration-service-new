package com.fincore.TemplateConfigurationService.constants;

/**
 * Centralised string constants for all API response messages.
 */
@SuppressWarnings("unused")
public final class ResponseMessages {

    private ResponseMessages() { /* utility class */ }

    // ── Template CRUD ────────────────────────────────────────────────────────
    public static final String TEMPLATE_SAVED          = "Template saved successfully";
    public static final String TEMPLATE_UPDATED        = "Template updated successfully";
    public static final String TEMPLATE_DELETED        = "Template deleted successfully";
    public static final String TEMPLATE_FETCHED        = "Template fetched successfully";
    public static final String ALL_TEMPLATES_FETCHED   = "All templates fetched successfully";

    // ── Variant messages ─────────────────────────────────────────────────────
    public static final String VARIANTS_UPDATED        = "Variants updated successfully";
    public static final String VARIANT_DELETED         = "Variant deleted successfully";

    // ── Status ───────────────────────────────────────────────────────────────
    public static final String STATUS_UPDATED          = "Template status updated successfully";

    // ── Request / approval sub-package ──────────────────────────────────────
    public static final String REQUEST_APPROVAL_PROCESSED = "Approved request processed successfully";
    public static final String REQUEST_VALIDATION_PASSED  = "Template payload is valid. Safe to submit for approval.";

    // ── Error messages ───────────────────────────────────────────────────────
    public static final String TEMPLATE_NOT_FOUND      = "Template not found: ";
    public static final String INVALID_JSON            = "Invalid template JSON";

    // ── Whitelist validation messages ────────────────────────────────────────
    public static final String MISSING_TABLE_ERROR     = "Disallowed tables found: ";
    public static final String INACTIVE_TABLE_ERROR    = "Inactive tables found: ";
    public static final String VALIDATION_FAILED       = "Whitelist validation failed → ";
    public static final String INTERNAL_ERROR          = "Internal error while validating template whitelist";
}
