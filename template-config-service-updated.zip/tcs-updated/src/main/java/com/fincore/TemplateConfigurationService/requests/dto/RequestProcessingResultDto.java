package com.fincore.TemplateConfigurationService.requests.dto;

import lombok.*;

/**
 * Response DTO returned after processing an approved request.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequestProcessingResultDto {

    /** The CRS requestId that was processed. */
    private Long requestId;

    /** The template ID that was created, updated, or deleted. */
    private String templateId;

    /** Human-readable outcome. */
    private String message;

    /** The change that was applied. */
    private ChangeType changeType;
}
