package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "RB_REPORT_TEMPLATE_HISTORY")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportTemplateHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "HISTORY_ID")
    private long historyId;

    // I store the original Template ID for reference
    @Column(name = "TEMPLATE_ID")
    private String templateId;

    @Column(name = "VERSION_NO")
    private Integer versionNo;

    @Column(name = "report_id")
    private String reportId;

    @Column(name = "TEMPLATE_NAME", length = 200)
    private String templateName;

    @Column(name = "DESCRIPTION", length = 500)
    private String description;

    @Column(name = "STATUS",length = 30)
    private String status;

    // Snapshot of the main template json
    @Lob
    @Column(name = "TEMPLATE_JSON")
    private String templateJson;

    // Snapshot of all variants + params + rules as a JSON array
    @Lob
    @Column(name = "VARIANTS_JSON")
    private String variantsJson;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "ARCHIVED_BY", length = 50)
    private String archivedBy;

    @Column(name = "ARCHIVED_AT")
    private LocalDateTime archivedAt;

    @Column(name = "REMARKS", length = 500)
    private String remarks;

}