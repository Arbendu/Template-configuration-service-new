package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.ReportTemplateHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ReportTemplateHistoryRepository extends JpaRepository<ReportTemplateHistory, Long> {
    Optional<Object> findByTemplateIdAndVersionNo(String templateId, int version);
}