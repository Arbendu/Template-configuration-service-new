package com.fincore.TemplateConfigurationService.requests.dto;

import com.fincore.TemplateConfigurationService.dto.TemplatePayload;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.*;

/**
 * DTO used by the maker / UI to validate a template payload BEFORE
 * submitting it to common-request-service for approval.
 *
 * <p>Endpoint: {@code POST /api/requests/validate}</p>
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequestValidationDto {

    /**
     * Indicates the intended operation so the validator can apply
     * context-specific rules (e.g. an ACTIVE template must exist before UPDATE).
     */
    @NotNull(message = "changeType is required")
    private ChangeType changeType;

    /**
     * For UPDATE/DELETE: the reportId of the target template.
     * Optional for ADD.
     */
    private String targetId;

    /** The full template payload to validate. */
    @NotNull(message = "payload is required")
    @Valid
    private TemplatePayload payload;
}
