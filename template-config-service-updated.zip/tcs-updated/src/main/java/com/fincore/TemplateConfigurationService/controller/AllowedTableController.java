package com.fincore.TemplateConfigurationService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fincore.TemplateConfigurationService.dto.AllowedTablesDTO;
import com.fincore.TemplateConfigurationService.service.AllowedTableService;


@RestController
@RequestMapping("/api/allowed-tables")
public class AllowedTableController {

    @Autowired
    private AllowedTableService tableService;

    @GetMapping("/tables")
    public  ResponseEntity<List<AllowedTablesDTO>> getAllTables(){
        return ResponseEntity.ok(tableService.getTableWithColumnsAll());
    }

    @GetMapping("/{tableId}")
    public ResponseEntity<AllowedTablesDTO> getAllowedTables(@PathVariable Long tableId) {
        return ResponseEntity.ok(tableService.getTableWithColumns(tableId));
    }
    
}