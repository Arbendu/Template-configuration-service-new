package com.fincore.TemplateConfigurationService.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fincore.TemplateConfigurationService.dto.TemplatePayload;
import com.fincore.TemplateConfigurationService.dto.TemplateResponse;
import com.fincore.TemplateConfigurationService.dto.VariantDto;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.enums.TemplateStatus;

import java.util.List;

public interface TemplateService {

    ReportTemplate createOrUpdateTemplate(TemplatePayload payload, String userId);

    TemplateResponse getTemplateWithVariants(String templateId) throws JsonProcessingException;

    List<TemplateResponse> getAllTemplates();

    void deleteTemplate(String templateId);

    void updateStatus(String templateId, TemplateStatus status, String userId);

    //public List<TemplateSummaryDto> getAllTemplates();

//    void updateStatus(String templateId, String status, String userId);
//
//    void updateVariants(String templateId, List<VariantDto> variants, String userId);
//
//    void updateTemplateOnly(String templateId, ReportTemplate updated, String userId);
}