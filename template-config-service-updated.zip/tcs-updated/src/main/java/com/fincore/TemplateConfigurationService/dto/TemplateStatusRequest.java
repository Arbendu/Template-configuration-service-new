package com.fincore.TemplateConfigurationService.dto;

import com.fincore.TemplateConfigurationService.enums.TemplateStatus;
import jakarta.validation.constraints.NotNull;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateStatusRequest {
    @NotNull
    private TemplateStatus status;
}