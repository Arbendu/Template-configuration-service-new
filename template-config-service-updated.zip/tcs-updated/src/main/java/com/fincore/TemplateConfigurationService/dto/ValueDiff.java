package com.fincore.TemplateConfigurationService.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ValueDiff {
    private Object oldValue;
    private Object newValue;
}