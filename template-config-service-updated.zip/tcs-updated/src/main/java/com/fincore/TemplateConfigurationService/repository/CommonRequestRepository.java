package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.CommonReq;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface CommonRequestRepository extends JpaRepository<CommonReq, Long> {
}