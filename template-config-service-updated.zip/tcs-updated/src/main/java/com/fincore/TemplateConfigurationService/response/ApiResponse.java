package com.fincore.TemplateConfigurationService.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class ApiResponse {
    private String message;
    private Object data;
    private String status; // SUCCESS / ERROR
    private LocalDateTime timestamp;
    private String path;
}