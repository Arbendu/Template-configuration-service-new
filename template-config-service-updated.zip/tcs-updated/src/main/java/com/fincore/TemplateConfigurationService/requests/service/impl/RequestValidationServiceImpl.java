package com.fincore.TemplateConfigurationService.requests.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fincore.TemplateConfigurationService.dto.*;
import com.fincore.TemplateConfigurationService.exception.BadRequestException;
import com.fincore.TemplateConfigurationService.repository.AllowedTablesRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import com.fincore.TemplateConfigurationService.repository.ReportVariantRepository;
import com.fincore.TemplateConfigurationService.requests.dto.ChangeType;
import com.fincore.TemplateConfigurationService.requests.dto.RequestValidationDto;
import com.fincore.TemplateConfigurationService.requests.service.RequestValidationService;
import jakarta.validation.ValidationException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlEngine;
import org.apache.commons.jexl3.JexlException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Strict template payload validator.
 *
 * <p>Migrated from {@code TemplateValidationService} in common-request-service.
 * Adapted to use TCS repositories, DTOs, and entity types.</p>
 *
 * <h2>Validation gates (in order)</h2>
 * <ol>
 *   <li>Structural integrity – metadata, columns, rows, cells</li>
 *   <li>Business-rule guard – UPDATE requires an existing ACTIVE template</li>
 *   <li>Cell ID assignment for formula reference tracking</li>
 *   <li>Dynamic-row configuration rules and resource limits</li>
 *   <li>Formula syntax (JEXL) and circular-dependency detection</li>
 *   <li>DB whitelist – every table/column referenced in the template must be
 *       present in {@code RB_ALLOWED_TABLES / RB_ALLOWED_COLUMNS} and must satisfy
 *       selectable / filterable / aggregation constraints</li>
 *   <li>Variant definitions and cross-variant rules</li>
 *   <li>"Doom check" – hard limit on estimated DB query count</li>
 * </ol>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RequestValidationServiceImpl implements RequestValidationService {

    private final AllowedTablesRepository allowedTablesRepository;
    private final ReportTemplateRepository reportTemplateRepository;
    private final ReportVariantRepository  reportVariantRepository;
    private final ObjectMapper             objectMapper;

    // ── Regex patterns ────────────────────────────────────────────────────────
    private static final Pattern SQL_IDENTIFIER_PATTERN = Pattern.compile("^[A-Za-z0-9_]+$");
    private static final Pattern ROW_ID_PATTERN         = Pattern.compile("^R__[A-Za-z0-9]+$");
    private static final Pattern COL_ID_PATTERN         = Pattern.compile("^C__[A-Za-z0-9]+$");
    private static final Pattern CELL_REF_PATTERN       = Pattern.compile("cell_(R[A-Za-z0-9_]+)_(C[A-Za-z0-9_]+)");

    // ── Limits ────────────────────────────────────────────────────────────────
    private static final int MAX_TOTAL_SPECS   = 5000;
    private static final int MAX_DYNAMIC_LIMIT = 10000;

    // ── Whitelists ────────────────────────────────────────────────────────────
    private static final Set<String> ALLOWED_PAGE_SIZES    = Set.of("A4", "A3", "A5", "LETTER", "LEGAL");
    private static final Set<String> ALLOWED_ORIENTATIONS  = Set.of("PORTRAIT", "LANDSCAPE");
    private static final Set<String> ALLOWED_ROW_TYPES     = Set.of("DATA", "DYNAMIC", "HEADER", "FOOTER", "GROUP_START", "GROUP_END");
    private static final Set<String> ALLOWED_CELL_TYPES    = Set.of(
            "TEXT", "FORMULA", "DB_VALUE", "DB_SUM", "DB_COUNT", "DB_AVG", "DB_MIN", "DB_MAX", "DB_DATE", "DB_TEXT");
    private static final Set<String> ALLOWED_OPERATORS     = Set.of("=", "!=", ">", "<", ">=", "<=", "LIKE", "IN", "BETWEEN");
    private static final Set<String> ALLOWED_VARIANT_SCOPES = Set.of("ALL_DB", "TABLE", "DYNAMIC_TABLE", "TAG");
    private static final Set<String> ALLOWED_PARAM_TYPES   = Set.of("STRING", "NUMBER", "DATE", "LIST");
    private static final Set<String> VALID_ORDER_DIRS      = Set.of("ASC", "DESC");
    private static final Set<String> IGNORED_KEYWORDS      = Set.of(
            "null", "true", "false", "math", "abs", "min", "max", "round", "ceil", "floor",
            "size", "empty", "new", "and", "or", "not", "eq", "ne", "lt", "gt", "le", "ge",
            "div", "mod", "string");

    // ── JEXL engine (shared, thread-safe) ─────────────────────────────────────
    private static final JexlEngine JEXL = new JexlBuilder().silent(false).strict(true).create();

    // =========================================================================
    // PUBLIC ENTRY POINT
    // =========================================================================

    @Override
    public void validate(RequestValidationDto dto) {
        TemplatePayload request = dto.getPayload();

        if (request == null)               throw new BadRequestException("Payload cannot be null");
        if (request.getTemplate() == null) throw new BadRequestException("template block is missing");

        TemplatePayload.Template t = request.getTemplate();

        // Gate 1: Metadata
        validateMetadata(t);

        // Gate 2: Column definitions
        validateColumns(t);

        // Gate 3: Business-rule guard (UPDATE requires active template)
        validateChangeTypeRules(dto);

        // Gate 4: Assign cell IDs (needed for formula reference resolution)
        assignCellIds(t);

        // Gate 5: Rows, cells, dynamic config – returns ctx for later gates
        ValidationContext ctx = validateRowsAndCells(t);

        // Gate 6: Formula syntax and circular dependency
        validateFormulasAndCircularDependencies(t);

        // Gate 7: DB whitelist / schema permissions
        validateSchemaPermissions(ctx.dbRequirements);
        log.info("Schema validation passed: {}", ctx.dbRequirements.keySet());

        // Gate 8: Variant definitions
        if (request.getVariants() != null) {
            validateVariants(request.getVariants(), ctx.tablesUsed);
        }

        // Gate 9: Doom check
        if (ctx.totalEstimatedSpecs > MAX_TOTAL_SPECS) {
            throw new BadRequestException(String.format(
                    "DOOM CHECK FAILED: Template is too heavy. Estimated DB queries: %d, max: %d. " +
                    "Reduce dynamic row limits or split the report.",
                    ctx.totalEstimatedSpecs, MAX_TOTAL_SPECS));
        }
    }

    // =========================================================================
    // GATE 1 – Metadata
    // =========================================================================

    private void validateMetadata(TemplatePayload.Template t) {
        if (t.getTemplateMeta() == null) throw new BadRequestException("templateMeta is required");
        if (t.getReportMeta()   == null) throw new BadRequestException("reportMeta is required");
        if (isBlank(t.getReportMeta().getReportName())) throw new BadRequestException("reportName is required");
        if (t.getReportData()   == null) throw new BadRequestException("reportData object must be present");

        String size = t.getTemplateMeta().getPageSize();
        if (size != null && !ALLOWED_PAGE_SIZES.contains(size.toUpperCase())) {
            throw new BadRequestException("Invalid pageSize: " + size + ". Allowed: " + ALLOWED_PAGE_SIZES);
        }
        String orient = t.getTemplateMeta().getPageOrientation();
        if (orient != null && !ALLOWED_ORIENTATIONS.contains(orient.toUpperCase())) {
            throw new BadRequestException("Invalid pageOrientation: " + orient + ". Allowed: " + ALLOWED_ORIENTATIONS);
        }
    }

    // =========================================================================
    // GATE 2 – Column definitions
    // =========================================================================

    private void validateColumns(TemplatePayload.Template t) {
        List<TemplatePayload.ColumnDefinition> cols = t.getReportData().getColumns();
        if (cols == null || cols.isEmpty()) {
            throw new BadRequestException("columns list cannot be null or empty");
        }
        Set<String> seen = new HashSet<>();
        for (TemplatePayload.ColumnDefinition c : cols) {
            if (!COL_ID_PATTERN.matcher(c.getId()).matches()) {
                throw new BadRequestException("Invalid column id format: " + c.getId() + " (must match C__<alphanum>)");
            }
            if (!seen.add(c.getId())) {
                throw new BadRequestException("Duplicate column id: " + c.getId());
            }
            if (isBlank(c.getName())) {
                throw new BadRequestException("Column 'name' is mandatory for id: " + c.getId());
            }
        }
    }

    // =========================================================================
    // GATE 3 – Business-rule guard
    // =========================================================================

    private void validateChangeTypeRules(RequestValidationDto dto) {
        if (dto.getChangeType() == ChangeType.UPDATE) {
            String reportId = dto.getPayload().getTemplate().getReportMeta().getReportId();
            boolean activeExists = reportTemplateRepository.existsByReportIdAndStatus(reportId, "ACTIVE");
            if (!activeExists) {
                throw new ValidationException(
                        "Cannot submit UPDATE request: no ACTIVE template found for reportId=" + reportId);
            }
        }
    }

    // =========================================================================
    // CELL ID ASSIGNMENT (prerequisite for formula references)
    // =========================================================================

    public void assignCellIds(TemplatePayload.Template t) {
        List<TemplatePayload.Row> rows = t.getReportData().getRows();
        if (rows == null) return;

        int rowNum = 0;
        for (TemplatePayload.Row row : rows) {
            if (row.getCells() == null) { rowNum++; continue; }
            if (isBlank(row.getId())) {
                throw new BadRequestException("Row id cannot be blank at index " + rowNum);
            }
            int colNum = 0;
            for (TemplatePayload.Cell cell : row.getCells()) {
                if (isBlank(cell.getId())) {
                    if (colNum >= t.getReportData().getColumns().size()) {
                        throw new BadRequestException("Cell at row " + rowNum + " col " + colNum + " exceeds column definitions");
                    }
                    cell.setId("cell_" + row.getId() + "_" + t.getReportData().getColumns().get(colNum).getId());
                }
                colNum++;
            }
            rowNum++;
        }
    }

    // =========================================================================
    // GATE 5 – Rows, cells, dynamic config
    // =========================================================================

    private ValidationContext validateRowsAndCells(TemplatePayload.Template t) {
        ValidationContext ctx = new ValidationContext();
        if (t.getReportData().getRows() == null) return ctx;

        int colCount = t.getReportData().getColumns().size();
        int rowIdx   = 0;

        for (TemplatePayload.Row row : t.getReportData().getRows()) {
            rowIdx++;
            if (!ROW_ID_PATTERN.matcher(row.getId()).matches()) {
                throw new BadRequestException("Invalid row id '" + row.getId() + "' at index " + rowIdx + " (must match R__<alphanum>)");
            }
            if (row.getRowType() == null || !ALLOWED_ROW_TYPES.contains(row.getRowType())) {
                throw new BadRequestException("Invalid rowType: " + row.getRowType());
            }

            if ("DYNAMIC".equalsIgnoreCase(row.getRowType())) {
                ctx.totalEstimatedSpecs += validateDynamicRow(row, ctx);
                continue;
            }

            if ("DATA".equalsIgnoreCase(row.getRowType()) && row.getCells() != null) {
                if (row.getCells().size() > colCount) {
                    throw new BadRequestException("Row " + row.getId() + " has " + row.getCells().size() +
                            " cells but only " + colCount + " columns are defined");
                }
                for (TemplatePayload.Cell cell : row.getCells()) {
                    ctx.totalEstimatedSpecs += validateCell(cell, row.getId(), ctx);
                }
            }
        }
        return ctx;
    }

    private long validateDynamicRow(TemplatePayload.Row row, ValidationContext ctx) {
        Map<String, Object> cfg = row.getDynamicConfig();
        if (cfg == null) throw new BadRequestException("DYNAMIC row " + row.getId() + " requires dynamicConfig");
        if (!"DB_LIST".equals(cfg.get("type"))) {
            throw new BadRequestException("Row " + row.getId() + ": only DB_LIST type is currently supported");
        }

        String table = (String) cfg.get("table");
        validateIdentifier(table, "Row " + row.getId() + " table");
        ctx.tablesUsed.add(table.toUpperCase());

        @SuppressWarnings("unchecked")
        List<String> select = (List<String>) cfg.get("select");
        if (select == null || select.isEmpty()) {
            throw new BadRequestException("Row " + row.getId() + ": 'select' field list is required");
        }
        select.forEach(col -> addDbRequirement(ctx, table, col, null, false, true));

        int limit = cfg.containsKey("limit") ? ((Number) cfg.get("limit")).intValue() : 300;
        if (limit < 1 || limit > MAX_DYNAMIC_LIMIT) {
            throw new BadRequestException("Row " + row.getId() + ": limit must be between 1 and " + MAX_DYNAMIC_LIMIT);
        }

        @SuppressWarnings("unchecked")
        Map<String, Object> filters = (Map<String, Object>) cfg.get("filters");
        validateFilters(filters, "Row " + row.getId(), table, ctx);

        String orderBy = (String) cfg.get("orderby");
        if (orderBy != null && !orderBy.isBlank()) {
            validateOrderBy(orderBy, select);
        }

        return (long) select.size() * limit;
    }

    private long validateCell(TemplatePayload.Cell cell, String rowId, ValidationContext ctx) {
        if (cell.getType() == null) return 0;
        String type = cell.getType().toUpperCase();

        if (!ALLOWED_CELL_TYPES.contains(type)) {
            throw new BadRequestException("Row " + rowId + ": invalid cell type '" + type + "'");
        }
        if (cell.getRender() != null) {
            Number colspan = (Number) cell.getRender().get("colspan");
            Number rowspan = (Number) cell.getRender().get("rowspan");
            if (colspan != null && colspan.intValue() < 1) throw new BadRequestException("colspan must be >= 1");
            if (rowspan != null && rowspan.intValue() < 1) throw new BadRequestException("rowspan must be >= 1");
        }
        if (type.startsWith("DB_")) {
            Map<String, Object> src = cell.getSource();
            if (src == null) throw new BadRequestException("Row " + rowId + ": DB cell is missing 'source'");
            String table = (String) src.get("table");
            String col   = (String) src.get("column");
            validateIdentifier(table, rowId + " source.table");
            validateIdentifier(col,   rowId + " source.column");
            ctx.tablesUsed.add(table.toUpperCase());
            addDbRequirement(ctx, table, col, type, false, true);

            @SuppressWarnings("unchecked")
            Map<String, Object> filters = (Map<String, Object>) src.get("filters");
            validateFilters(filters, rowId, table, ctx);
            return 1;
        }
        if ("FORMULA".equals(type)) {
            return validateFormulaCell(cell, rowId, ctx);
        }
        return 0;
    }

    private long validateFormulaCell(TemplatePayload.Cell cell, String rowId, ValidationContext ctx) {
        if (isBlank(cell.getExpression())) return 0;

        try {
            JEXL.createExpression(cell.getExpression());
        } catch (JexlException e) {
            throw new BadRequestException("Row " + rowId + ": invalid JEXL formula: " + e.getMessage());
        }

        long inlineSpecs = 0;
        if (cell.getVariables() != null) {
            for (Map.Entry<String, Object> entry : cell.getVariables().entrySet()) {
                if (entry.getValue() instanceof Map) {
                    @SuppressWarnings("unchecked")
                    Map<String, Object> varCfg = (Map<String, Object>) entry.getValue();
                    String varType = (String) varCfg.get("type");
                    if (varType != null && varType.startsWith("DB_")) {
                        String table = (String) varCfg.get("table");
                        String col   = (String) varCfg.get("column");
                        validateIdentifier(table, rowId + " var.table");
                        validateIdentifier(col,   rowId + " var.column");
                        ctx.tablesUsed.add(table.toUpperCase());
                        addDbRequirement(ctx, table, col, varType, false, true);

                        @SuppressWarnings("unchecked")
                        Map<String, Object> filters = (Map<String, Object>) varCfg.get("filters");
                        validateFilters(filters, rowId, table, ctx);
                        inlineSpecs++;
                    }
                }
            }
        }
        return inlineSpecs;
    }

    // =========================================================================
    // GATE 6 – Formula syntax + circular dependencies
    // =========================================================================

    private void validateFormulasAndCircularDependencies(TemplatePayload.Template t) {
        Map<String, Set<String>> graph       = new HashMap<>();
        Set<String>              formulaCells = new HashSet<>();

        if (t.getReportData().getRows() == null) return;

        for (TemplatePayload.Row row : t.getReportData().getRows()) {
            if (row.getCells() == null) continue;
            for (TemplatePayload.Cell cell : row.getCells()) {
                if (!"FORMULA".equalsIgnoreCase(cell.getType())) continue;

                String cellId = cell.getId();
                if (cellId == null) continue;

                formulaCells.add(cellId);
                graph.putIfAbsent(cellId, new HashSet<>());

                // Dependencies from variables typed CELL_REF
                if (cell.getVariables() != null) {
                    for (Object varVal : cell.getVariables().values()) {
                        if (varVal instanceof Map<?,?> m && "CELL_REF".equals(m.get("type"))) {
                            graph.get(cellId).add((String) m.get("ref"));
                        }
                    }
                }

                // Dependencies inferred from the expression tokens
                if (cell.getExpression() != null) {
                    Matcher m = Pattern.compile("[A-Za-z0-9_]+").matcher(cell.getExpression());
                    while (m.find()) {
                        String token = m.group();
                        if (cell.getVariables() != null && cell.getVariables().containsKey(token)) {
                            graph.get(cellId).add(token);
                            continue;
                        }
                        if (token.matches("^\\d+$")) continue;
                        if (IGNORED_KEYWORDS.contains(token.toLowerCase())) continue;

                        Matcher refMatcher = CELL_REF_PATTERN.matcher(token);
                        if (refMatcher.matches()) {
                            String refRow = refMatcher.group(1);
                            String refCol = refMatcher.group(2);
                            if (!validateCellExists(t, refRow, refCol)) {
                                throw new BadRequestException("Cell reference '" + token + "' (row=" + refRow + ", col=" + refCol + ") does not exist");
                            }
                            graph.get(cellId).add(token);
                        } else {
                            throw new BadRequestException("Undefined reference in formula expression: '" + token + "'");
                        }
                    }
                }
            }
        }

        Set<String> visited        = new HashSet<>();
        Set<String> recursionStack = new HashSet<>();
        for (String cellId : formulaCells) {
            if (detectCycle(cellId, graph, visited, recursionStack)) {
                throw new BadRequestException("Circular dependency detected involving cell: " + cellId);
            }
        }
    }

    private boolean detectCycle(String current, Map<String, Set<String>> graph,
                                 Set<String> visited, Set<String> recursionStack) {
        if (recursionStack.contains(current)) return true;
        if (visited.contains(current))        return false;

        visited.add(current);
        recursionStack.add(current);

        Set<String> neighbors = graph.get(current);
        if (neighbors != null) {
            for (String n : neighbors) {
                if (detectCycle(n, graph, visited, recursionStack)) return true;
            }
        }
        recursionStack.remove(current);
        return false;
    }

    private boolean validateCellExists(TemplatePayload.Template t, String rowId, String colId) {
        if (t.getReportData() == null) return false;
        boolean rowOk = t.getReportData().getRows().stream().anyMatch(r -> rowId.equals(r.getId()));
        boolean colOk = t.getReportData().getColumns().stream().anyMatch(c -> colId.equals(c.getId()));
        return rowOk && colOk;
    }

    // =========================================================================
    // GATE 7 – DB whitelist / schema permissions
    // =========================================================================

    private void validateSchemaPermissions(Map<String, Set<ColumnUsage>> requirements) {
        if (requirements.isEmpty()) return;

        // Bulk-load the allowed schema from RB_ALLOWED_TABLES / RB_ALLOWED_COLUMNS
        Map<String, AllowedTablesDTO> allowedSchema = allowedTablesRepository.findAll()
                .stream()
                .filter(t -> "Y".equalsIgnoreCase(t.getActive()))
                .map(AllowedTablesDTO::new)
                .collect(Collectors.toMap(AllowedTablesDTO::getTableName, dto -> dto));

        for (Map.Entry<String, Set<ColumnUsage>> entry : requirements.entrySet()) {
            String tableName = entry.getKey();

            if (!allowedSchema.containsKey(tableName)) {
                throw new BadRequestException("Security violation: table '" + tableName + "' is not whitelisted");
            }

            Map<String, AllowedColumnsDTO> colMeta = allowedSchema.get(tableName).getColumns()
                    .stream()
                    .collect(Collectors.toMap(c -> c.getColumnName().toUpperCase(), c -> c));

            for (ColumnUsage usage : entry.getValue()) {
                String colName = usage.column.toUpperCase();
                AllowedColumnsDTO meta = colMeta.get(colName);

                if (meta == null) {
                    throw new BadRequestException("Column '" + colName + "' does not exist in table '" + tableName + "'");
                }
                if (usage.isSelectable && !"Y".equals(meta.getSelectable())) {
                    throw new BadRequestException("Column '" + colName + "' in table '" + tableName + "' is not selectable");
                }
                if (usage.isUsedInFilter && !"Y".equals(meta.getFilterable())) {
                    throw new BadRequestException("Column '" + colName + "' in table '" + tableName + "' is not filterable");
                }
                if (usage.aggType != null) {
                    boolean isNumeric = "NUMBER".equalsIgnoreCase(meta.getDataType()) || "DECIMAL".equalsIgnoreCase(meta.getDataType());
                    if (Set.of("DB_SUM", "DB_AVG").contains(usage.aggType) && !isNumeric) {
                        throw new BadRequestException("Aggregation " + usage.aggType + " requires a numeric column; got: " + meta.getDataType());
                    }
                }
            }
        }
    }

    // =========================================================================
    // GATE 8 – Variant definitions
    // =========================================================================

    private void validateVariants(List<VariantDto> variants, Set<String> tablesUsed) {
        Set<String> codes = new HashSet<>();
        for (VariantDto v : variants) {
            validateIdentifier(v.getVariantCode(), "variantCode");
            if (!codes.add(v.getVariantCode())) {
                throw new BadRequestException("Duplicate variantCode: " + v.getVariantCode());
            }
            if (v.getParams() != null) {
                for (VariantParamDto p : v.getParams()) {
                    validateIdentifier(p.getParamName(), "param name");
                    if (!ALLOWED_PARAM_TYPES.contains(p.getParamType())) {
                        throw new BadRequestException("Invalid param type: " + p.getParamType() + " for param " + p.getParamName());
                    }
                    if (p.getValidation() != null) {
                        try { Pattern.compile(p.getValidation()); }
                        catch (Exception e) { throw new BadRequestException("Invalid regex for param '" + p.getParamName() + "'"); }
                    }
                }
            }
            if (v.getFilterRules() != null) {
                for (FilterRuleDto r : v.getFilterRules()) {
                    if (r.getScopeType() != null && !ALLOWED_VARIANT_SCOPES.contains(r.getScopeType())) {
                        throw new BadRequestException("Invalid variant scope type: " + r.getScopeType());
                    }
                    if (r.getOperator() != null && !ALLOWED_OPERATORS.contains(r.getOperator())) {
                        throw new BadRequestException("Invalid variant rule operator: " + r.getOperator());
                    }
                    validateIdentifier(r.getDbColumn(), "variant rule dbColumn");
                    if ("TABLE".equals(r.getScopeType()) && r.getScopeValue() != null) {
                        if (!tablesUsed.contains(r.getScopeValue().toUpperCase())) {
                            throw new BadRequestException("Variant rule references table '" + r.getScopeValue() +
                                    "' which is not used in the template");
                        }
                    }
                }
            }
        }
    }

    // =========================================================================
    // SHARED HELPERS
    // =========================================================================

    private void validateFilters(Map<String, Object> filters, String context, String tableName, ValidationContext ctx) {
        if (filters == null) return;
        for (Map.Entry<String, Object> entry : filters.entrySet()) {
            validateIdentifier(entry.getKey(), context + " filter key");
            addDbRequirement(ctx, tableName, entry.getKey(), null, true, true);

            Object val = entry.getValue();
            if (val instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> fMap = (Map<String, Object>) val;
                String op = (String) fMap.get("op");
                if (op != null && !ALLOWED_OPERATORS.contains(op.toUpperCase())) {
                    throw new BadRequestException(context + ": invalid filter operator '" + op + "'");
                }
                if ("IN".equalsIgnoreCase(op) && !(fMap.get("value") instanceof List)) {
                    throw new BadRequestException(context + ": IN operator requires a List value");
                }
                if ("BETWEEN".equalsIgnoreCase(op)) {
                    if (!(fMap.get("value") instanceof List) || ((List<?>) fMap.get("value")).size() != 2) {
                        throw new BadRequestException(context + ": BETWEEN operator requires a List of exactly 2 values");
                    }
                }
            }
        }
    }

    private void validateOrderBy(String orderBy, List<String> selectCols) {
        for (String part : orderBy.split(",")) {
            String[] tokens = part.trim().split("\\s+");
            if (tokens.length > 2) throw new BadRequestException("Invalid ORDER BY clause: " + part);
            String col = tokens[0];
            if (!selectCols.contains(col)) throw new BadRequestException("ORDER BY column '" + col + "' must be in the select list");
            if (col.contains(";") || col.contains("--") || col.contains("'") || col.contains("/*")) {
                throw new BadRequestException("Possible SQL injection in ORDER BY: " + col);
            }
            if (tokens.length == 2 && !VALID_ORDER_DIRS.contains(tokens[1].toUpperCase())) {
                throw new BadRequestException("Invalid sort direction: " + tokens[1]);
            }
        }
    }

    private void validateIdentifier(String id, String context) {
        if (isBlank(id)) throw new BadRequestException(context + " cannot be empty");
        if (!SQL_IDENTIFIER_PATTERN.matcher(id).matches()) {
            throw new BadRequestException("Security error: " + context + " '" + id + "' contains invalid characters (alphanumeric + underscore only)");
        }
    }

    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    private void addDbRequirement(ValidationContext ctx, String table, String col,
                                   String aggType, boolean isFilter, boolean isSelectable) {
        ctx.dbRequirements
                .computeIfAbsent(table.toUpperCase(), k -> new HashSet<>())
                .add(new ColumnUsage(col, aggType, isFilter, isSelectable));
    }

    // =========================================================================
    // INNER CLASSES – validation state
    // =========================================================================

    private static class ValidationContext {
        long                          totalEstimatedSpecs = 0;
        Set<String>                   tablesUsed          = new HashSet<>();
        Map<String, Set<ColumnUsage>> dbRequirements      = new HashMap<>();
    }

    private static class ColumnUsage {
        final String  column;
        final String  aggType;
        final boolean isUsedInFilter;
        final boolean isSelectable;

        ColumnUsage(String column, String aggType, boolean isUsedInFilter, boolean isSelectable) {
            this.column        = column;
            this.aggType       = aggType;
            this.isUsedInFilter = isUsedInFilter;
            this.isSelectable  = isSelectable;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof ColumnUsage that)) return false;
            return isUsedInFilter == that.isUsedInFilter
                    && isSelectable == that.isSelectable
                    && Objects.equals(column, that.column)
                    && Objects.equals(aggType, that.aggType);
        }

        @Override
        public int hashCode() {
            return Objects.hash(column, aggType, isSelectable, isUsedInFilter);
        }
    }
}
