package com.fincore.TemplateConfigurationService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TemplateConfigurationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TemplateConfigurationServiceApplication.class, args);
	}

}