package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.VariantParamDef;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface VariantParamDefRepository extends JpaRepository<VariantParamDef, Long> {

    @Query("SELECT v FROM VariantParamDef v WHERE v.reportVariant.variantId IN :variantIds")
    List<VariantParamDef> findByVariantIdIn(@Param("variantIds") List<Long> variantIds);

    //List<VariantParamDef> findByVariantId(Long variantId);

    @Modifying
    @Query("DELETE FROM VariantParamDef v WHERE v.reportVariant.variantId = :variantId")
    void deleteByVariantId(@Param("variantId") Long variantId);
}