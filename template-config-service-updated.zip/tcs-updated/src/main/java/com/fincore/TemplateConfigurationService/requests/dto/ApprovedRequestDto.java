package com.fincore.TemplateConfigurationService.requests.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.*;

/**
 * DTO received from common-request-service (CRS) when a template request
 * has been approved by a checker and needs to be actioned in TCS.
 *
 * <p>CRS calls {@code POST /api/requests/process-approval} with this payload.</p>
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApprovedRequestDto {

    /** The CRS REQ_ID of the approved request. */
    @NotNull(message = "requestId is required")
    private Long requestId;

    /** Type of change: ADD, UPDATE, or DELETE. */
    @NotNull(message = "changeType is required")
    private ChangeType changeType;

    /** User ID of the maker who submitted the request. */
    @NotBlank(message = "creatorId is required")
    private String creatorId;

    /** User ID of the checker who approved the request. */
    @NotBlank(message = "executorId is required")
    private String executorId;

    /**
     * For UPDATE/DELETE: the reportId of the existing template to operate on.
     * May be null for ADD operations.
     */
    private String targetId;

    /**
     * The raw JSON payload of the original request.
     * Must be a valid serialised {@link com.fincore.TemplateConfigurationService.dto.TemplatePayload}.
     */
    @NotBlank(message = "payload is required")
    private String payload;
}
