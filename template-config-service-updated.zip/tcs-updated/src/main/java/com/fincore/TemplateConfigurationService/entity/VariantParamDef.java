package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "RB_VARIANT_PARAM_DEF")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VariantParamDef {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PARAM_ID")
    private Long paramId;

//    @Column(name = "VARIANT_ID")
//    private Long variantId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "VARIANT_ID", nullable = false)
    private ReportVariant reportVariant;

    @Column(name = "PARAM_NAME", length = 100)
    private String paramName;

    @Column(name = "LABEL", length = 200)
    private String label;

    @Column(name = "PARAM_TYPE", length = 50)
    private String paramType;

    @Column(name = "REQUIRED_YN", length = 1)
    private String required; // 'Y' or 'N'

    @Column(name = "MULTI_VALUED_YN", length = 1)
    private String multiVal; // 'Y' or 'N'

    @Column(name = "UI_HINT", length = 50)
    private String uiHint;

    @Column(name = "VALIDATION_REGEX", length = 500)
    private String validation;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;
}