package com.fincore.TemplateConfigurationService.requests.service;

import com.fincore.TemplateConfigurationService.requests.dto.ApprovedRequestDto;
import com.fincore.TemplateConfigurationService.requests.dto.RequestProcessingResultDto;

/**
 * Processes an approved template request forwarded from common-request-service.
 *
 * <p>Supports ADD (create), UPDATE (version increment + archive), and DELETE
 * (archive + hard-delete) operations on {@code RB_REPORT_TEMPLATE} and
 * its child entities (variants, params, filter-rules).</p>
 */
public interface RequestApprovalService {

    /**
     * Executes the approved template change.
     *
     * @param dto the approved request details, including the serialised payload
     * @return processing result containing template ID and outcome message
     */
    RequestProcessingResultDto processApproval(ApprovedRequestDto dto);
}
