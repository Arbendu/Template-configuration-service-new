package com.fincore.TemplateConfigurationService.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FilterRuleDto {

    @NotBlank
    private String scopeType;

    @NotBlank
    private String scopeValue;

    @NotBlank
    private String paramName;

    @NotBlank
    private String dbColumn;

    @NotBlank
    private String operator;
}