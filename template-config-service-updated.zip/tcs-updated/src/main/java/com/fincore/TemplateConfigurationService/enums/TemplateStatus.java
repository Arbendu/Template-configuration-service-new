package com.fincore.TemplateConfigurationService.enums;

public enum TemplateStatus {
    ACTIVE,
    INACTIVE,
    DRAFT
}