package com.fincore.TemplateConfigurationService.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fincore.TemplateConfigurationService.dto.*;
import com.fincore.TemplateConfigurationService.entity.CommonReq;
import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import com.fincore.TemplateConfigurationService.entity.ReportVariant;
import com.fincore.TemplateConfigurationService.repository.CommonRequestRepository;
import com.fincore.TemplateConfigurationService.repository.ReportTemplateRepository;
import com.fincore.TemplateConfigurationService.repository.ReportVariantRepository;
import com.fincore.TemplateConfigurationService.service.TemplateDiffService;
import com.fincore.TemplateConfigurationService.util.JsonCompareUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class TemplateDiffServiceImpl implements TemplateDiffService {

    private final CommonRequestRepository commonRequestRepository;
    private final ReportTemplateRepository reportTemplateRepository;
    private final ReportVariantRepository reportVariantRepository;
    private final JsonCompareUtil jsonCompareUtil;
    private final ObjectMapper objectMapper;

    @Override
    public TemplateDiffResponseDto compareByRequestId(Long requestId) {

        // 1️⃣ Fetch NEW template from request payload
        CommonReq req = commonRequestRepository.findById(requestId)
                .orElseThrow(() ->
                        new IllegalArgumentException("Request not found: " + requestId));

        TemplatePayload newTemplate = parseTemplate(req.getPayload(), "request payload");

        // 2️⃣ Extract reportId safely
        String reportId = newTemplate.getTemplate()
                .getReportMeta()
                .getReportId();

        // 3️⃣ Fetch OLD ACTIVE template from DB
        ReportTemplate oldEntity = reportTemplateRepository
                .findFirstByReportIdAndStatus(reportId, "ACTIVE")
                .orElseThrow(() -> new IllegalStateException("Active template not found"));

        // Parse old template AND its variants
        TemplatePayload oldTemplate = parseTemplate(oldEntity.getTemplateJson(), "stored template");

//        String oldTemplateJson = reportTemplateRepository
//                .findFirstByReportIdAndStatus(reportId, "ACTIVE")
//                .map(rt -> rt.getTemplateJson())
//                .orElseThrow(() ->
//                        new IllegalStateException("Active template not found for reportId: " + reportId));
//
//        TemplatePayload oldTemplate = parseTemplate(oldTemplateJson, "stored template");

        // Fetch variants for the old template
        List<VariantDto> oldVariants = reportVariantRepository.findByTemplateId(oldEntity.getTemplateId())
                .stream()
                .map(this::mapToVariantDto).toList();

        oldTemplate.setVariants(oldVariants);           // Set variants to the old template

        // 4️⃣ Run diff logic
        // 4a. Compare Cells
        Map<String, Map<String, ValueDiff>> cellDiffs =
                jsonCompareUtil.compareCells(oldTemplate, newTemplate);

        // 4b. Compare Columns
        Map<String, Map<String, ValueDiff>> columnDiffs =
                jsonCompareUtil.compareColumns(oldTemplate, newTemplate);

        // 4c. Compare variants
        Map<String, Map<String, ValueDiff>> variantDiffs =
                jsonCompareUtil.compareVariants(oldTemplate.getVariants(), newTemplate.getVariants());

        // Compare Global Params
        Map<String, Map<String, ValueDiff>> globalParamDiffs = jsonCompareUtil.compareGlobalParams(
                oldTemplate.getTemplate().getGlobalParams(),
                newTemplate.getTemplate().getGlobalParams()
        );

        // 5️⃣ Response
        return TemplateDiffResponseDto.builder()
                .oldTemplate(oldTemplate)
                .newTemplate(newTemplate)
                .cellDiffs(cellDiffs)
                .columnDiffs(columnDiffs) // Add columns to response
                .variantDiffs(variantDiffs)
                .globalParamDiffs(globalParamDiffs)
                .build();
    }

    // Helper to map ReportVariant entity to VariantDto
    private VariantDto mapToVariantDto(ReportVariant entity){
        return VariantDto.builder()
                .variantCode(entity.getVariantCode())
                .variantName(entity.getVariantName())
                .description(entity.getDescription())
                .status(entity.getStatus())
                .params(entity.getParams() != null ? entity.getParams().stream()
                        .map(def -> VariantParamDto.builder()
                                .paramName(def.getParamName())
                                .label(def.getLabel())
                                .paramType(def.getParamType())
                                .validation(def.getValidation())
                                .uiHint(def.getUiHint())
                                .required("Y".equalsIgnoreCase(def.getRequired()))
                                .multiValued("Y".equalsIgnoreCase(def.getMultiVal())).build())
                        .toList() : new ArrayList<>())
                .filterRules(entity.getFilterRules() != null ? entity.getFilterRules().stream()
                        .map(rule -> FilterRuleDto.builder()
                                .dbColumn(rule.getDbColumn())
                                .operator(rule.getOperator())
                                .paramName(rule.getParamName())
                                .scopeType(rule.getScopeType())
                                .scopeValue(rule.getScopeValue())
                                .build())
                        .toList() : new ArrayList<>())
                .build();
    }

    private TemplatePayload parseTemplate(String json, String source) {
        try {
            TemplatePayload dto = objectMapper.readValue(json, TemplatePayload.class);
            if (dto.getTemplate() != null) {
                return dto;
            }

            // Fallback: wrap flat JSON into Template structure
            Map<String, Object> raw = objectMapper.readValue(json, Map.class);
            TemplatePayload.Template template = TemplatePayload.Template.builder()
                    .templateMeta(objectMapper.convertValue(raw.get("templateMeta"), TemplatePayload.TemplateMeta.class))
                    .reportMeta(objectMapper.convertValue(raw.get("reportMeta"), TemplatePayload.ReportMeta.class))
                    .reportData(objectMapper.convertValue(raw.get("reportData"), TemplatePayload.ReportData.class))
                    .build();

            return TemplatePayload.builder()
                    .template(template)
                    .variants(List.of())
                    .build();
        } catch (Exception e) {
            throw new IllegalStateException("Invalid " + source + " JSON", e);
        }
    }
}