package com.fincore.TemplateConfigurationService.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "RB_REPORT_TEMPLATE")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReportTemplate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "TEMPLATE_ID")
    private String templateId;

    @Column(name = "VERSION_NO")
    private Integer versionNo;

    @Column(name = "REPORT_ID")
    private String reportId;

    @Column(name = "TEMPLATE_NAME", length = 200)
    private String templateName;

    @Column(name = "DESCRIPTION", length = 500)
    private String description;

    @Column(name = "STATUS", length = 30)
    private String status;

    @Lob
    @Column(name = "TEMPLATE_JSON")
    private String templateJson;

    @Column(name = "CREATED_BY", length = 50)
    private String createdBy;

    @Column(name = "CREATED_AT")
    private LocalDateTime createdAt;

    @Column(name = "UPDATED_BY", length = 50)
    private String updatedBy;

    @Column(name = "UPDATED_AT")
    private LocalDateTime updatedAt;

    @Column(name = "REMARKS", length = 500)
    private String remarks;
}