package com.fincore.TemplateConfigurationService.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VariantDto {

    @NotBlank
    private String variantCode;

    @NotBlank
    private String variantName;

    private String description;

    @Builder.Default
    private String status = "ACTIVE";

    private List<VariantParamDto> params;

    private List<FilterRuleDto> filterRules;
}