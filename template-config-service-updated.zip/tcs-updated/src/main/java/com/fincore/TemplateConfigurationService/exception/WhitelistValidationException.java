package com.fincore.TemplateConfigurationService.exception;

public class WhitelistValidationException extends RuntimeException{
    public WhitelistValidationException(String message){
        super(message);
    }

    public WhitelistValidationException(String message, Throwable cause){
        super(message, cause);
    }
}