package com.fincore.TemplateConfigurationService.dto;

import com.fincore.TemplateConfigurationService.entity.AllowedColumns;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AllowedColumnsDTO {

    private Long columnId;
    private String columnName;
    private String label;
    private String dataType;
    private String selectable;
    private String filterable;
    private String aggFuncs;

    public AllowedColumnsDTO(AllowedColumns entity) {
        this.columnId = entity.getId();
        this.columnName = entity.getColumnName();
        this.label = entity.getLabel();
        this.dataType=entity.getDataType();
        this.selectable = entity.getSelectable();
        this.filterable = entity.getFilterable();
        this.aggFuncs = entity.getAggFuncs();
    }

    
}