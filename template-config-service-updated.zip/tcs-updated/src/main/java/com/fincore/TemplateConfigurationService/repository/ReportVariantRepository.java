package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.ReportVariant;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface  ReportVariantRepository extends JpaRepository<ReportVariant, Long> {

    List<ReportVariant> findByTemplateIdIn(List<String> templateIds);

    List<ReportVariant> findByTemplateId(String templateId);

    //void deleteByTemplateId(String templateId);

//    Optional<ReportVariant> findByTemplateIdAndVariantCode(String templateId, String variantCode);
//
//    boolean existsByTemplateIdAndVariantCode(String templateId, String variantCode);
}