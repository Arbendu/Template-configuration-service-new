package com.fincore.TemplateConfigurationService.dto;

import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplateResponse {

    private String templateId;
    private String reportId;
    private String templateName;
    private String  description;
    private String status;
    private Integer versionNo;
    private Map<String, Object> template;
    private List<VariantResponse> variants;

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class VariantResponse{
        private String variantCode;
        private String variantName;
        private String description;
        private String status;
        private List<VariantParamDto> params;
        private List<FilterRuleDto> filterRules;
    }

}