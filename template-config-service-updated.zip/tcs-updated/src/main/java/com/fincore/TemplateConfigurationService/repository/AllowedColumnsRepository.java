package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.AllowedColumns;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AllowedColumnsRepository extends JpaRepository<AllowedColumns, Long> {

    /**
     * Batch fetch allowed columns (case-insensitive)
     * for selected tables and column names.
     */
    @Query("""
           SELECT c\s
           FROM AllowedColumns c\s
           WHERE c.table.id IN :tableIds
             AND UPPER(c.columnName) IN :columnNames
          \s""")
    List<AllowedColumns> findByTableIdInAndColumnNameInIgnoreCase(
            List<Long> tableIds,
            List<String> columnNames
    );
}