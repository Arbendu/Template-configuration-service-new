package com.fincore.TemplateConfigurationService.dto;

import java.util.*;
import java.util.stream.Collectors;

import com.fincore.TemplateConfigurationService.entity.AllowedTables;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllowedTablesDTO {

    private Long tableId;
    private String tableName;
    private String label;
    private List<AllowedColumnsDTO> columns;

    public AllowedTablesDTO(AllowedTables table) {
        this.tableId = table.getId();
        this.tableName = table.getTableName();
        this.label = table.getLabel();
        this.columns = table.getColumns().stream().filter(c -> "Y".equalsIgnoreCase(c.getActive())).map(AllowedColumnsDTO::new).collect(Collectors.toList());
    }
}