package com.fincore.TemplateConfigurationService.entity;


import java.util.ArrayList;
import java.util.List;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "RB_ALLOWED_TABLES")

public class AllowedTables {

    @Id
    @Column(name = "ID", nullable = false)
    private Long id;

    @Column(name = "TABLE_NAME", nullable = false)
    private String tableName;

    @Column(name = "LABEL")
    private String label;

    @Column(name = "ACTIVE", nullable = false)
    private String active;

    @OneToMany(mappedBy = "table", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<AllowedColumns> columns =new ArrayList<>();
}