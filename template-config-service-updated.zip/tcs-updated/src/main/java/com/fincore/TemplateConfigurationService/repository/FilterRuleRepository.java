package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.FilterRule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FilterRuleRepository extends JpaRepository<FilterRule, Long> {

    @Query("SELECT f FROM FilterRule f WHERE f.reportVariant.variantId IN :variantIds")
    List<FilterRule> findByVariantIdIn(@Param("variantIds") List<Long> variantIds);

    @Modifying
    @Query("DELETE FROM FilterRule f WHERE f.reportVariant.variantId = :variantId")
    void deleteByVariantId(@Param("variantId") Long variantId);
}