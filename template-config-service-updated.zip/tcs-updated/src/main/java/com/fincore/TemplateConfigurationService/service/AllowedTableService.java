package com.fincore.TemplateConfigurationService.service;

import java.util.*;
import com.fincore.TemplateConfigurationService.dto.AllowedTablesDTO;

public interface AllowedTableService {
    AllowedTablesDTO getTableWithColumns(Long tableId);

    List<AllowedTablesDTO> getTableWithColumnsAll();
}