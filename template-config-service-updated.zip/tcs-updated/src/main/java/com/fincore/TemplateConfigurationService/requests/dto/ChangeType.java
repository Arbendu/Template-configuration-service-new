package com.fincore.TemplateConfigurationService.requests.dto;

import lombok.Getter;

/**
 * Enumerates the types of changes supported for a template request.
 * Mirrors the ChangeType enum from common-request-service for request processing.
 */
@Getter
public enum ChangeType {

    /** Create a new template (ADD). */
    ADD("A"),

    /** Modify an existing template (UPDATE). */
    UPDATE("U"),

    /** Remove an existing template (DELETE). */
    DELETE("D");

    private final String code;

    ChangeType(String code) {
        this.code = code;
    }
}
