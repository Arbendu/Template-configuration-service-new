package com.fincore.TemplateConfigurationService.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TemplatePayload{

    @NotNull
    private Template template;

    @NotNull
    private List<VariantDto> variants;

    private String remarks;


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class Template {
        @NotNull
        private TemplateMeta templateMeta;

        @NotNull
        private ReportMeta reportMeta;

//        private List<Map<String, Object>> globalParams;
        private List<GlobalParamDef> globalParams;

        @NotNull
        private ReportData reportData;
    }

    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class TemplateMeta {
        private String templateId;
        private String version;
        private String description;
        // e.g. "A4", "LETTER"; "portrait" / "landscape"
        private String pageSize;
        private String pageOrientation;
        private String headerLayout;  //layout (1-col, 2-col, etc.)
    }

    @Data
    public static class ReportMeta {
        private String reportName;
        private String reportId;
        private List<Map<String, String>> extras;
    }

    @Data
    public static class ReportData {
        private List<ColumnDefinition> columns;
        private List<Row> rows;
    }
    @Data
    public static class GlobalParamDef {
        private String name;           // e.g., "BRANCH_NAME"
        private String dataType;       // STRING, NUMBER, DATE, BOOLEAN
        private String label;

        // NEW: Mode of execution
        private ParamMode mode;        // INPUT, EXPRESSION, QUERY

        // For INPUT
        private Object defaultValue;
        private boolean required;

        // For EXPRESSION
        private String expression;     // e.g., "#{DateUtils.addDays(G.REPORT_DATE, -1)}"

        // For QUERY
        private ParamDataSource source; // DB Config
    }

    public enum ParamMode {
        INPUT,          // Provided by user or defaults
        EXPRESSION,     // Calculated using JEXL
        QUERY           // Fetched from Database
    }

    @Data
    public static class ParamDataSource {
        private String type;           // DB_VALUE, DB_SUM, etc.
        private String table;
        private String column;
        // Filters: Map<ColumnName, List<Condition>>
        private Map<String, Object> filters;
    }

    @Data
    public static class ColumnDefinition {
        private String id;
        private String name;
        private Map<String, Object> format; // flexible formatting map
        private List<TemplateColumnFilter> templateColumnFilters;
    }

    @Data
    public static class TemplateColumnFilter {
        private String tableName;

        // Maps Column Name -> List of Conditions (e.g., "BALANCE": [{op:">", value:"0"}])
        private Map<String, Object> filters;
    }

    @Data
    public static class Row {
        /**
         * DATA|GROUP_START|GROUP_END|NOTE|BREAK|DYNAMIC (future)
         */
        private String id;
        private String rowType;
        private String rowTitle;
        private List<Cell> cells;

        // Extension point for dynamic blocks etc.
        // Example: { "type":"DB_LIST", "table":"...", "filters":{...}, "limit":100 }
        private Map<String, Object> dynamicConfig;
    }

    @Data
    public static class Cell {
        private String id;                     // assigned by TemplateProcessor (R{row}C{col})
        private String type;                   // TEXT, DB_*, FORMULA, etc.
        private Object value;                  // used for TEXT cells
        private String expression;             // used for formulas
        private Map<String, Object> variables; // formula vars (CELL_REF, DB_*, CONST, etc.)
        private Map<String, Object> source;    // for DB_* types: { table, column, filters }
        private Map<String, Object> render;    // { bold, colspan, rowspan, align, format, bgColor, ... }
    }


}