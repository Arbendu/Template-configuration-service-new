package com.fincore.TemplateConfigurationService.service.impl;

import com.fincore.TemplateConfigurationService.dto.AllowedTablesDTO;
import com.fincore.TemplateConfigurationService.entity.AllowedTables;
import com.fincore.TemplateConfigurationService.exception.TemplateNotFoundException;
import com.fincore.TemplateConfigurationService.repository.AllowedTablesRepository;
import com.fincore.TemplateConfigurationService.service.AllowedTableService;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@Service
public class AllowedTableServiceImpl implements AllowedTableService {

    @Autowired
    private AllowedTablesRepository repository;
    private AllowedTables table;

    @Override
    public AllowedTablesDTO getTableWithColumns(Long tableId) {
        AllowedTables table = repository.findById(tableId)
                .orElseThrow(() -> new TemplateNotFoundException("Table Not Found"));
        return new AllowedTablesDTO(table);
    }

    @Override
    public List<AllowedTablesDTO> getTableWithColumnsAll() {
        return repository.findAll().stream().filter(c -> "Y".equalsIgnoreCase(c.getActive())).map(AllowedTablesDTO::new).collect(Collectors.toList());
    }

}