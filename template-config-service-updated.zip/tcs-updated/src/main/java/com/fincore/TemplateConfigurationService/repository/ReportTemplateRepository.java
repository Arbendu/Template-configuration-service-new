package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.ReportTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ReportTemplateRepository extends JpaRepository<ReportTemplate, String> {

    Optional<ReportTemplate> findFirstByReportId(String reportId);

    Optional<ReportTemplate> findFirstByReportIdAndStatus(String reportId, String status);

    /**
     * Used by {@link com.fincore.TemplateConfigurationService.requests.service.impl.RequestValidationServiceImpl}
     * to enforce the business rule that an UPDATE request requires an existing ACTIVE template.
     */
    boolean existsByReportIdAndStatus(String reportId, String status);
}
