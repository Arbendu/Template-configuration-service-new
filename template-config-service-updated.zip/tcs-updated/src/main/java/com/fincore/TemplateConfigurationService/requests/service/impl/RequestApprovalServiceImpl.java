package com.fincore.TemplateConfigurationService.requests.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fincore.TemplateConfigurationService.dto.*;
import com.fincore.TemplateConfigurationService.entity.*;
import com.fincore.TemplateConfigurationService.exception.BadRequestException;
import com.fincore.TemplateConfigurationService.exception.TemplateNotFoundException;
import com.fincore.TemplateConfigurationService.repository.*;
import com.fincore.TemplateConfigurationService.requests.dto.ApprovedRequestDto;
import com.fincore.TemplateConfigurationService.requests.dto.ChangeType;
import com.fincore.TemplateConfigurationService.requests.dto.RequestProcessingResultDto;
import com.fincore.TemplateConfigurationService.requests.service.RequestApprovalService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Processes approved template requests forwarded from common-request-service.
 *
 * <p>Migrated from {@code ReportTemplateConfigStrategy} in common-request-service.
 * Adapted to use TCS entities ({@link ReportVariant}, {@link FilterRule},
 * {@link VariantParamDef}) and TCS DTOs ({@link TemplatePayload}, {@link VariantDto},
 * {@link FilterRuleDto}, {@link VariantParamDto}).</p>
 *
 * <h2>Behaviour by ChangeType</h2>
 * <ul>
 *   <li><b>ADD</b> – If an ACTIVE template exists for the same reportId it is archived
 *       (moved to history) and deleted before the new one is inserted.</li>
 *   <li><b>UPDATE</b> – The existing ACTIVE template is archived; version number is
 *       incremented; the record is updated in-place with the new JSON and variants.</li>
 *   <li><b>DELETE</b> – The existing ACTIVE template is archived and then hard-deleted.</li>
 * </ul>
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RequestApprovalServiceImpl implements RequestApprovalService {

    private final ObjectMapper objectMapper;
    private final ReportTemplateRepository templateRepository;
    private final ReportVariantRepository variantRepository;
    private final VariantParamDefRepository paramDefRepository;
    private final FilterRuleRepository filterRuleRepository;
    private final ReportTemplateHistoryRepository historyRepository;

    // =========================================================================
    // PUBLIC ENTRY POINT
    // =========================================================================

    @Override
    @Transactional
    public RequestProcessingResultDto processApproval(ApprovedRequestDto dto) {
        log.info("Processing approved request id={} changeType={}", dto.getRequestId(), dto.getChangeType());

        return switch (dto.getChangeType()) {
            case ADD    -> handleCreate(dto);
            case UPDATE -> handleUpdate(dto);
            case DELETE -> handleDelete(dto);
        };
    }

    // =========================================================================
    // ADD – Create new template (archive existing if present)
    // =========================================================================

    private RequestProcessingResultDto handleCreate(ApprovedRequestDto dto) {
        TemplatePayload payload = deserialize(dto.getPayload());
        TemplatePayload.Template templateDto = payload.getTemplate();

        String reportId   = templateDto.getReportMeta().getReportId();
        int    version    = parseVersion(templateDto.getTemplateMeta().getVersion(), 1);
        LocalDateTime now = LocalDateTime.now();

        // Archive + delete any existing ACTIVE template for this reportId
        templateRepository.findFirstByReportIdAndStatus(reportId, "ACTIVE").ifPresent(existing -> {
            archiveTemplate(existing, dto.getExecutorId(), now);
            deleteVariants(existing.getTemplateId());
            templateRepository.delete(existing);
            log.info("Archived and removed previous ACTIVE template id={}", existing.getTemplateId());
        });

        // Persist the new template
        ReportTemplate newTemplate = ReportTemplate.builder()
                .reportId(reportId)
                .templateName(templateDto.getReportMeta().getReportName())
                .description(templateDto.getTemplateMeta().getDescription())
                .versionNo(version)
                .status("ACTIVE")
                .templateJson(serialize(templateDto))
                .createdAt(now)
                .createdBy(dto.getCreatorId())
                .updatedAt(now)
                .updatedBy(dto.getExecutorId())
                .remarks(payload.getRemarks())
                .build();

        ReportTemplate saved = templateRepository.save(newTemplate);
        saveVariants(payload.getVariants(), saved, dto.getCreatorId(), dto.getExecutorId(), now);

        log.info("ADD: created template id={} reportId={} version={}", saved.getTemplateId(), reportId, version);
        return RequestProcessingResultDto.builder()
                .requestId(dto.getRequestId())
                .templateId(saved.getTemplateId())
                .changeType(ChangeType.ADD)
                .message("Template created successfully.")
                .build();
    }

    // =========================================================================
    // UPDATE – Increment version, archive old, persist updated data
    // =========================================================================

    private RequestProcessingResultDto handleUpdate(ApprovedRequestDto dto) {
        requireTargetId(dto);

        ReportTemplate existing = templateRepository.findFirstByReportId(dto.getTargetId())
                .orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + dto.getTargetId()));

        TemplatePayload payload    = deserialize(dto.getPayload());
        TemplatePayload.Template t = payload.getTemplate();
        LocalDateTime now          = LocalDateTime.now();

        // Archive current state before modification
        archiveTemplate(existing, dto.getExecutorId(), now);

        // Increment version and inject it back into the template meta JSON
        int newVersion = existing.getVersionNo() + 1;
        t.getTemplateMeta().setVersion(String.valueOf(newVersion));

        existing.setVersionNo(newVersion);
        existing.setReportId(t.getReportMeta().getReportId());
        existing.setTemplateName(t.getReportMeta().getReportName());
        existing.setDescription(t.getTemplateMeta().getDescription());
        existing.setTemplateJson(serialize(t));
        existing.setRemarks(payload.getRemarks());
        existing.setUpdatedAt(now);
        existing.setUpdatedBy(dto.getExecutorId());

        ReportTemplate saved = templateRepository.save(existing);

        // Wipe all old variants and insert the new set
        deleteVariants(saved.getTemplateId());
        saveVariants(payload.getVariants(), saved, saved.getCreatedBy(), dto.getExecutorId(), now);

        log.info("UPDATE: template id={} bumped to version {}", saved.getTemplateId(), newVersion);
        return RequestProcessingResultDto.builder()
                .requestId(dto.getRequestId())
                .templateId(saved.getTemplateId())
                .changeType(ChangeType.UPDATE)
                .message("Template updated to version " + newVersion + ".")
                .build();
    }

    // =========================================================================
    // DELETE – Archive and hard-delete
    // =========================================================================

    private RequestProcessingResultDto handleDelete(ApprovedRequestDto dto) {
        requireTargetId(dto);

        ReportTemplate template = templateRepository.findFirstByReportId(dto.getTargetId())
                .orElseThrow(() -> new TemplateNotFoundException("Template not found for reportId: " + dto.getTargetId()));

        String templateId = template.getTemplateId();
        archiveTemplate(template, dto.getExecutorId(), LocalDateTime.now());
        deleteVariants(templateId);
        templateRepository.delete(template);

        log.info("DELETE: archived and removed template id={}", templateId);
        return RequestProcessingResultDto.builder()
                .requestId(dto.getRequestId())
                .templateId(templateId)
                .changeType(ChangeType.DELETE)
                .message("Template deleted successfully.")
                .build();
    }

    // =========================================================================
    // HELPER – Archive a template + snapshot its variants to history
    // =========================================================================

    private void archiveTemplate(ReportTemplate template, String archivedBy, LocalDateTime archivedAt) {
        String variantsSnapshot = fetchVariantsAsJson(template.getTemplateId());

        ReportTemplateHistory history = ReportTemplateHistory.builder()
                .templateId(template.getTemplateId())
                .reportId(template.getReportId())
                .versionNo(template.getVersionNo())
                .templateName(template.getTemplateName())
                .description(template.getDescription())
                .status("INACTIVE")
                .templateJson(template.getTemplateJson())
                .variantsJson(variantsSnapshot)
                .createdBy(template.getCreatedBy())
                .createdAt(template.getCreatedAt())
                .archivedBy(archivedBy)
                .archivedAt(archivedAt)
                .remarks(template.getRemarks())
                .build();

        historyRepository.save(history);
        log.debug("Archived template id={} version={} to history", template.getTemplateId(), template.getVersionNo());
    }

    /**
     * Serialises the full variant object-graph (variant → params + rules) as a JSON snapshot
     * for archival purposes.
     */
    private String fetchVariantsAsJson(String templateId) {
        try {
            List<ReportVariant> variants = variantRepository.findByTemplateId(templateId);
            List<VariantDto>    dtos     = new ArrayList<>();

            for (ReportVariant v : variants) {
                List<Long> singletonId = Collections.singletonList(v.getVariantId());

                List<VariantParamDef> params = paramDefRepository.findByVariantIdIn(singletonId);
                List<FilterRule>      rules  = filterRuleRepository.findByVariantIdIn(singletonId);

                VariantDto dto = VariantDto.builder()
                        .variantCode(v.getVariantCode())
                        .variantName(v.getVariantName())
                        .description(v.getDescription())
                        .status(v.getStatus())
                        .params(params.stream().map(p -> VariantParamDto.builder()
                                .paramName(p.getParamName())
                                .label(p.getLabel())
                                .paramType(p.getParamType())
                                .required("Y".equalsIgnoreCase(p.getRequired()))
                                .multiValued("Y".equalsIgnoreCase(p.getMultiVal()))
                                .uiHint(p.getUiHint())
                                .validation(p.getValidation())
                                .build()).collect(Collectors.toList()))
                        .filterRules(rules.stream().map(r -> FilterRuleDto.builder()
                                .dbColumn(r.getDbColumn())
                                .operator(r.getOperator())
                                .paramName(r.getParamName())
                                .scopeType(r.getScopeType())
                                .scopeValue(r.getScopeValue())
                                .build()).collect(Collectors.toList()))
                        .build();

                dtos.add(dto);
            }

            return objectMapper.writeValueAsString(dtos);
        } catch (Exception e) {
            log.error("Failed to serialise variants for history snapshot, templateId={}", templateId, e);
            return "[]";
        }
    }

    // =========================================================================
    // HELPER – Persist variants, params, and filter-rules
    // =========================================================================

    private void saveVariants(List<VariantDto> variantDtos,
                               ReportTemplate template,
                               String creatorId,
                               String executorId,
                               LocalDateTime now) {
        if (variantDtos == null || variantDtos.isEmpty()) return;

        for (VariantDto dto : variantDtos) {
            ReportVariant variant = ReportVariant.builder()
                    .templateId(template.getTemplateId())
                    .variantCode(dto.getVariantCode())
                    .variantName(dto.getVariantName())
                    .description(dto.getDescription())
                    .status(dto.getStatus() != null ? dto.getStatus() : "ACTIVE")
                    .createdAt(now)
                    .createdBy(creatorId)
                    .updatedAt(now)
                    .updatedBy(executorId)
                    .build();

            ReportVariant saved = variantRepository.save(variant);

            if (dto.getParams() != null) {
                for (VariantParamDto p : dto.getParams()) {
                    paramDefRepository.save(VariantParamDef.builder()
                            .reportVariant(saved)
                            .paramName(p.getParamName())
                            .label(p.getLabel())
                            .paramType(p.getParamType())
                            .required(p.isRequired() ? "Y" : "N")
                            .multiVal(p.isMultiValued() ? "Y" : "N")
                            .uiHint(p.getUiHint())
                            .validation(p.getValidation())
                            .createdAt(now)
                            .build());
                }
            }

            if (dto.getFilterRules() != null) {
                for (FilterRuleDto r : dto.getFilterRules()) {
                    filterRuleRepository.save(FilterRule.builder()
                            .reportVariant(saved)
                            .scopeType(r.getScopeType())
                            .scopeValue(r.getScopeValue())
                            .paramName(r.getParamName())
                            .dbColumn(r.getDbColumn())
                            .operator(r.getOperator())
                            .createdAt(now)
                            .build());
                }
            }
        }
    }

    /**
     * Removes all variants (and their params / filter-rules) for the given templateId.
     */
    private void deleteVariants(String templateId) {
        List<ReportVariant> variants = variantRepository.findByTemplateId(templateId);
        if (variants.isEmpty()) return;

        for (ReportVariant v : variants) {
            paramDefRepository.deleteByVariantId(v.getVariantId());
            filterRuleRepository.deleteByVariantId(v.getVariantId());
        }
        variantRepository.deleteAll(variants);
        log.debug("Deleted all variants for templateId={}", templateId);
    }

    // =========================================================================
    // UTILITY
    // =========================================================================

    private TemplatePayload deserialize(String json) {
        try {
            return objectMapper.readValue(json, TemplatePayload.class);
        } catch (Exception e) {
            throw new BadRequestException("Invalid template payload JSON: " + e.getMessage());
        }
    }

    private String serialize(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new BadRequestException("Failed to serialise template JSON: " + e.getMessage());
        }
    }

    private int parseVersion(String version, int defaultValue) {
        if (version == null || version.isBlank()) return defaultValue;
        try {
            return Integer.parseInt(version);
        } catch (NumberFormatException e) {
            log.warn("Non-numeric version '{}', defaulting to {}", version, defaultValue);
            return defaultValue;
        }
    }

    private void requireTargetId(ApprovedRequestDto dto) {
        if (dto.getTargetId() == null || dto.getTargetId().isBlank()) {
            throw new BadRequestException("targetId is required for " + dto.getChangeType() + " operations");
        }
    }
}
