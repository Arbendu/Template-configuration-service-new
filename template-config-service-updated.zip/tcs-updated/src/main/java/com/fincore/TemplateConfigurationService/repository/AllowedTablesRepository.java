package com.fincore.TemplateConfigurationService.repository;

import com.fincore.TemplateConfigurationService.entity.AllowedTables;

import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


@Repository
public interface AllowedTablesRepository extends JpaRepository<AllowedTables, Long> {

    @Query(value = "SELECT t.ID AS table_id, t.TABLE_NAME AS table_name, t.LABEL AS table_label, c.ID AS column_id, c.COLUMN_NAME AS column_name, c.LABEl AS column_label," +
            " c.DATA_TYPE AS data_type, c.SELECTABLE AS selectable, c.FILTERABLE AS filterable, c.AGG-FUNCS AS agg_funcs FROM RB_ALLOWED_TABLES t LEFT JOIN RB_ALLOWED_COLUMNS c ON c.TABLE_ID = t.ID " +
            "AND c.ACTIVE = 'Y' WHERE t.ACTIVE = 'Y' ORDER BY t.ID, c.ID", nativeQuery = true)

    List<Object[]> fetchTablesWithColumnsNative();
    @Query("""
            SELECT t FROM AllowedTables t WHERE UPPER(t.tableName) IN :tableNames
            """)
    List<AllowedTables> findByTableNameInIgnoreCase(Set<String> tableName);
}