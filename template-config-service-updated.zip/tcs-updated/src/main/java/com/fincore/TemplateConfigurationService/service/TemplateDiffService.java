package com.fincore.TemplateConfigurationService.service;

import com.fincore.TemplateConfigurationService.dto.TemplateDiffResponseDto;

public interface TemplateDiffService {

    TemplateDiffResponseDto compareByRequestId(Long requestId);
}