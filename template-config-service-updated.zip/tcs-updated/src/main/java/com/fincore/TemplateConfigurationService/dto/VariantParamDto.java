package com.fincore.TemplateConfigurationService.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VariantParamDto {

    @NotBlank
    private String paramName;

    @NotBlank
    private String label;

    @NotBlank
    private String paramType;

    private boolean required;

    private boolean multiValued;

    private String uiHint;

    private String validation;
}