package com.fincore.TemplateConfigurationService.validator;

public interface TemplateWhitelistValidator {

    void validate(String templateJson);
}