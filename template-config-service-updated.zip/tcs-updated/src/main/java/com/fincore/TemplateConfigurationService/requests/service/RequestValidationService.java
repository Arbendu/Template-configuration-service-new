package com.fincore.TemplateConfigurationService.requests.service;

import com.fincore.TemplateConfigurationService.requests.dto.RequestValidationDto;

/**
 * Validates a template payload before the maker submits it to
 * common-request-service for approval.
 *
 * <p>Enforces structural integrity, security (DB whitelist), formula syntax,
 * circular-dependency detection, and business rules such as
 * "an ACTIVE template must exist before UPDATE".</p>
 */
public interface RequestValidationService {

    /**
     * Runs all validation gates against {@code dto.payload}.
     * Throws {@link com.fincore.TemplateConfigurationService.exception.BadRequestException}
     * on the first violation detected.
     *
     * @param dto validation input
     */
    void validate(RequestValidationDto dto);
}
