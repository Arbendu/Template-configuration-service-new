// ***********************************************************************************************
// Added CompareColumn Diff  ----> Now you can detect the changes in column definition.
// ***********************************************************************************************


package com.fincore.TemplateConfigurationService.util;

import com.fincore.TemplateConfigurationService.dto.TemplatePayload;
import com.fincore.TemplateConfigurationService.dto.ValueDiff;
import com.fincore.TemplateConfigurationService.dto.VariantDto;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class JsonCompareUtil {

    /**
     * Compare Rows and Cells
     */
    public Map<String, Map<String, ValueDiff>> compareCells(
            TemplatePayload oldTemplate,
            TemplatePayload newTemplate
    ) {
        Map<String, Map<String, ValueDiff>> diffs = new LinkedHashMap<>();

        List<TemplatePayload.Row> oldRows = getRowsSafe(oldTemplate);
        List<TemplatePayload.Row> newRows = getRowsSafe(newTemplate);

        int maxRows = Math.max(oldRows.size(), newRows.size());

        for (int r = 0; r < maxRows; r++) {
            TemplatePayload.Row oldRow = r < oldRows.size() ? oldRows.get(r) : null;
            TemplatePayload.Row newRow = r < newRows.size() ? newRows.get(r) : null;

            // If a row is completely missing or added, you might handle it here.
            // For now, we proceed to check cells if both rows exist (or partially exist)
            List<TemplatePayload.Cell> oldCells = (oldRow != null) ? oldRow.getCells() : Collections.emptyList();
            List<TemplatePayload.Cell> newCells = (newRow != null) ? newRow.getCells() : Collections.emptyList();

            int maxCells = Math.max(oldCells.size(), newCells.size());

            for (int c = 0; c < maxCells; c++) {
                TemplatePayload.Cell oldCell = c < oldCells.size() ? oldCells.get(c) : null;
                TemplatePayload.Cell newCell = c < newCells.size() ? newCells.get(c) : null;

                if (oldCell == null && newCell == null) continue;

                String cellKey = buildCellKey(oldCell, newCell, r, c);
                Map<String, ValueDiff> fieldDiffs = compareCellFields(oldCell, newCell);

                if (!fieldDiffs.isEmpty()) {
                    diffs.put(cellKey, fieldDiffs);
                }
            }
        }
        return diffs;
    }

    /**
     * Compare Column Definitions
     */
    public Map<String, Map<String, ValueDiff>> compareColumns(
            TemplatePayload oldTemplate,
            TemplatePayload newTemplate
    ) {
        Map<String, Map<String, ValueDiff>> diffs = new LinkedHashMap<>();

        List<TemplatePayload.ColumnDefinition> oldCols = getColumnsSafe(oldTemplate);
        List<TemplatePayload.ColumnDefinition> newCols = getColumnsSafe(newTemplate);

        int maxCols = Math.max(oldCols.size(), newCols.size());

        for (int i = 0; i < maxCols; i++) {
            TemplatePayload.ColumnDefinition oldCol = i < oldCols.size() ? oldCols.get(i) : null;
            TemplatePayload.ColumnDefinition newCol = i < newCols.size() ? newCols.get(i) : null;

            if (oldCol == null && newCol == null) continue;

            // Generate a reliable key for the frontend to identify which column changed
            String colKey = buildColumnKey(oldCol, newCol, i);

            Map<String, ValueDiff> fieldDiffs = compareColumnFields(oldCol, newCol);

            if (!fieldDiffs.isEmpty()) {
                diffs.put(colKey, fieldDiffs);
            }
        }
        return diffs;
    }

    // 3. METHOD: Compare variants
    public Map<String, Map<String, ValueDiff>> compareVariants(
            List<VariantDto> oldVariants,
            List<VariantDto> newVariants
    ) {
        Map<String, Map<String, ValueDiff>> diffs = new LinkedHashMap<>();

        // Use a Set to collect all unique variant codes from both lists
        Set<String> allCodes = new LinkedHashSet<>();
        if (oldVariants != null) oldVariants.forEach(v -> allCodes.add(v.getVariantCode()));
        if (newVariants != null) newVariants.forEach(v -> allCodes.add(v.getVariantCode()));

        for (String code : allCodes) {
            VariantDto oldV = findVariantByCode(oldVariants, code);
            VariantDto newV = findVariantByCode(newVariants, code);

            Map<String, ValueDiff> fieldDiffs = new LinkedHashMap<>();

            // 1. Compare basic fields
            compareField("variantName",
                    oldV != null ? oldV.getVariantName() : null,
                    newV != null ? newV.getVariantName() : null, fieldDiffs);

            compareField("description",
                    oldV != null ? oldV.getDescription() : null,
                    newV != null ? newV.getDescription() : null, fieldDiffs);

            compareField("status",
                    oldV != null ? oldV.getStatus() : null,
                    newV != null ? newV.getStatus() : null, fieldDiffs);

            // 2. Compare complex lists (Params and Filter Rules)
            compareField("params",
                    oldV != null ? oldV.getParams() : null,
                    newV != null ? newV.getParams() : null, fieldDiffs);

            compareField("filterRules",
                    oldV != null ? oldV.getFilterRules() : null,
                    newV != null ? newV.getFilterRules() : null, fieldDiffs);

            if (!fieldDiffs.isEmpty()) {
                diffs.put(code, fieldDiffs);
            }
        }
        return diffs;
    }


    // 4. METHOD: Compare Global Params
    public Map<String, Map<String, ValueDiff>> compareGlobalParams(
            List<TemplatePayload.GlobalParamDef> oldParams,
            List<TemplatePayload.GlobalParamDef> newParams
    ) {
        Map<String, Map<String, ValueDiff>> diffs = new LinkedHashMap<>();
        Set<String> allNames = new LinkedHashSet<>();
        if (oldParams != null) oldParams.forEach(p -> allNames.add(p.getName()));
        if (newParams != null) newParams.forEach(p -> allNames.add(p.getName()));

        for (String name : allNames) {
            TemplatePayload.GlobalParamDef oldP = findParam(oldParams, name);
            TemplatePayload.GlobalParamDef newP = findParam(newParams, name);

            Map<String, ValueDiff> fieldDiffs = new LinkedHashMap<>();

            // Compare fields
            compareField("name", oldP != null ? oldP.getName() : null, newP != null ? newP.getName() : null, fieldDiffs);
            compareField("label", oldP != null ? oldP.getLabel() : null, newP != null ? newP.getLabel() : null, fieldDiffs);
            compareField("dataType", oldP != null ? oldP.getDataType() : null, newP != null ? newP.getDataType() : null, fieldDiffs);
            compareField("mode", oldP != null ? oldP.getMode() : null, newP != null ? newP.getMode() : null, fieldDiffs);
            compareField("expression", oldP != null ? oldP.getExpression() : null, newP != null ? newP.getExpression() : null, fieldDiffs);
            compareField("defaultValue", oldP != null ? oldP.getDefaultValue() : null, newP != null ? newP.getDefaultValue() : null, fieldDiffs);
            compareField("source", oldP != null ? oldP.getSource() : null, newP != null ? newP.getSource() : null, fieldDiffs);

            if (!fieldDiffs.isEmpty()) {
                diffs.put(name, fieldDiffs);
            }
        }
        return diffs;
    }

    // Helper to find params in the list
    private TemplatePayload.GlobalParamDef findParam(List<TemplatePayload.GlobalParamDef> list, String name) {
        if (list == null) return null;
        return list.stream().filter(p -> name.equals(p.getName())).findFirst().orElse(null);
    }


    // Helper to find a variant in the list by its code
    private VariantDto findVariantByCode(List<VariantDto> list, String code) {
        if (list == null || code == null) return null;
        return list.stream()
                .filter(v -> code.equals(v.getVariantCode()))
                .findFirst()
                .orElse(null);
    }

    // --------------------------------------------------------
    // Comparison Logic Helpers
    // --------------------------------------------------------

    private Map<String, ValueDiff> compareCellFields(TemplatePayload.Cell oldCell, TemplatePayload.Cell newCell) {
        Map<String, ValueDiff> diffs = new LinkedHashMap<>();

        // Handle nulls (Added/Removed cells)
        if (oldCell == null && newCell != null) {
            // Entire cell is new. We can mark key fields as changed from null -> value
            compareField("value", null, newCell.getValue(), diffs);
            return diffs;
        }
        if (oldCell != null && newCell == null) {
            // Cell removed
            compareField("value", oldCell.getValue(), null, diffs);
            return diffs;
        }

        compareField("type", oldCell.getType(), newCell.getType(), diffs);
        compareField("value", oldCell.getValue(), newCell.getValue(), diffs);
        compareField("expression", oldCell.getExpression(), newCell.getExpression(), diffs);
        compareField("variables", oldCell.getVariables(), newCell.getVariables(), diffs);
        compareField("source", oldCell.getSource(), newCell.getSource(), diffs);
        compareField("render", oldCell.getRender(), newCell.getRender(), diffs);
        return diffs;
    }

    private Map<String, ValueDiff> compareColumnFields(TemplatePayload.ColumnDefinition oldCol, TemplatePayload.ColumnDefinition newCol) {
        Map<String, ValueDiff> diffs = new LinkedHashMap<>();

        if (oldCol == null && newCol != null) {
            compareField("name", null, newCol.getName(), diffs);
            return diffs;
        }
        if (oldCol != null && newCol == null) {
            compareField("name", oldCol.getName(), null, diffs);
            return diffs;
        }

        assert oldCol != null;
        compareField("id", oldCol.getId(), newCol.getId(), diffs);
        compareField("name", oldCol.getName(), newCol.getName(), diffs);
        compareField("format", oldCol.getFormat(), newCol.getFormat(), diffs);
        compareField("filters",
                oldCol.getTemplateColumnFilters(),
                newCol.getTemplateColumnFilters(),
                diffs);

        return diffs;
    }

    private void compareField(String field, Object oldVal, Object newVal, Map<String, ValueDiff> diffs) {
        if (!Objects.equals(oldVal, newVal)) {
            diffs.put(field, new ValueDiff(oldVal, newVal));
        }
    }

    // --------------------------------------------------------
    // Key Generation Helpers
    // --------------------------------------------------------

    private String buildCellKey(TemplatePayload.Cell oldCell, TemplatePayload.Cell newCell, int r, int c) {
        if (newCell != null && newCell.getId() != null) return newCell.getId();
        if (oldCell != null && oldCell.getId() != null) return oldCell.getId();
        // Deterministic fallback
        return "R" + r + "C" + c;
    }

    private String buildColumnKey(TemplatePayload.ColumnDefinition oldCol, TemplatePayload.ColumnDefinition newCol, int index) {
        if (newCol != null && newCol.getId() != null) return newCol.getId();
        if (oldCol != null && oldCol.getId() != null) return oldCol.getId();
        // Deterministic fallback
        return "C" + index;
    }

    // --------------------------------------------------------
    // Null-Safe Accessors
    // --------------------------------------------------------

    private List<TemplatePayload.Row> getRowsSafe(TemplatePayload t) {
        if (t == null || t.getTemplate() == null
                || t.getTemplate().getReportData() == null
                || t.getTemplate().getReportData().getRows() == null) {
            return Collections.emptyList();
        }
        return t.getTemplate().getReportData().getRows();
    }

    private List<TemplatePayload.ColumnDefinition> getColumnsSafe(TemplatePayload t) {
        if (t == null || t.getTemplate() == null
                || t.getTemplate().getReportData() == null
                || t.getTemplate().getReportData().getColumns() == null) {
            return Collections.emptyList();
        }
        return t.getTemplate().getReportData().getColumns();
    }
}