package com.fincore.TemplateConfigurationService.validator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fincore.TemplateConfigurationService.constants.ResponseMessages;
import com.fincore.TemplateConfigurationService.entity.AllowedColumns;
import com.fincore.TemplateConfigurationService.entity.AllowedTables;
import com.fincore.TemplateConfigurationService.exception.WhitelistValidationException;
import com.fincore.TemplateConfigurationService.repository.AllowedColumnsRepository;
import com.fincore.TemplateConfigurationService.repository.AllowedTablesRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(prefix = "app.whitelist", name = "enabled", havingValue = "true", matchIfMissing = true)
public class TemplateWhitelistValidatorImpl implements TemplateWhitelistValidator {

    private final AllowedTablesRepository allowedTablesRepository;
    private final AllowedColumnsRepository allowedColumnsRepository;
    private final ObjectMapper objectMapper;

    // ===================================================
    // PUBLIC ENTRY
    // ===================================================
    @Override
    @Transactional(readOnly = true)
    public void validate(String templateJson) {
        if (templateJson == null || templateJson.isBlank()) {
            log.info("Whitelist validation skipped – template JSON empty");
            return;
        }

        try {
            JsonNode root = objectMapper.readTree(templateJson);

            // Extract DB usage
            Set<String> tables = new HashSet<>();
            Map<String, Set<String>> tableColumns = new HashMap<>();
            Map<String, Set<String>> usageType = new HashMap<>();     // TABLE|COL → SOURCE, FILTER, SELECT
            Map<String, Set<String>> requestedAggs = new HashMap<>(); // TABLE|COL → SUM, AVG, etc.

            extractDbReferences(root, tables, tableColumns, usageType, requestedAggs);

            if (tables.isEmpty()) {
                log.info("No DB references in template. Whitelist validation passed.");
                return;
            }

            // ===================================================
            // 1) BATCH QUERY TABLES
            // ===================================================
            List<AllowedTables> allowedTables = allowedTablesRepository.findByTableNameInIgnoreCase(tables);

            Map<String, AllowedTables> allowedTableMap =
                    allowedTables.stream().collect(Collectors.toMap(
                            t -> t.getTableName().toUpperCase(),
                            t -> t
                    ));

            // Validate missing tables
            List<String> missingTables = tables.stream()
                    .filter(t -> !allowedTableMap.containsKey(t.toUpperCase()))
                    .toList();

            if (!missingTables.isEmpty()) {
                throw new WhitelistValidationException(ResponseMessages.MISSING_TABLE_ERROR + missingTables);
            }

            // Validate table active
            List<String> inactiveTables = allowedTables.stream()
                    .filter(t -> !"Y".equalsIgnoreCase(t.getActive()))
                    .map(AllowedTables::getTableName)
                    .toList();

            if (!inactiveTables.isEmpty()) {
                throw new WhitelistValidationException(ResponseMessages.INACTIVE_TABLE_ERROR + inactiveTables);
            }

            // TableId lookup
            Map<String, Long> tableNameToId = allowedTables.stream()
                    .collect(Collectors.toMap(
                            t -> t.getTableName().toUpperCase(),
                            AllowedTables::getId
                    ));

            // Collect all referenced columns
            Set<String> allReferencedCols =
                    tableColumns.values().stream().flatMap(Set::stream)
                            .map(String::toUpperCase)
                            .collect(Collectors.toSet());

            // ===================================================
            // 2) BATCH QUERY COLUMNS
            // ===================================================
            List<AllowedColumns> allowedCols =
                    allowedColumnsRepository.findByTableIdInAndColumnNameInIgnoreCase(
                            new ArrayList<>(tableNameToId.values()),
                            new ArrayList<>(allReferencedCols)
                    );

            // Lookup: TABLE_ID|COLUMN
            Map<String, AllowedColumns> allowedColMap = new HashMap<>();
            for (AllowedColumns col : allowedCols) {
                String key = col.getTable().getId() + "|" + col.getColumnName().toUpperCase();
                allowedColMap.put(key, col);
            }

            // ===================================================
            // COLUMN VALIDATION
            // ===================================================
            List<String> errors = new ArrayList<>();

            for (String table : tableColumns.keySet()) {
                Long tableId = tableNameToId.get(table.toUpperCase());
                for (String col : tableColumns.get(table)) {

                    String key = tableId + "|" + col.toUpperCase();
                    AllowedColumns allowed = allowedColMap.get(key);

                    if (allowed == null) {
                        errors.add(table + "." + col + " → column not allowed");
                        continue;
                    }
                    if (!"Y".equalsIgnoreCase(allowed.getActive())) {
                        errors.add(table + "." + col + " → column inactive");
                    }

                    // SOURCE/SELECT usage requires selectable=Y
                    if (usageType.getOrDefault(table + "|" + col, Set.of()).contains("SOURCE") ||
                            usageType.getOrDefault(table + "|" + col, Set.of()).contains("SELECT")) {
                        if (!"Y".equalsIgnoreCase(allowed.getSelectable())) {
                            errors.add(table + "." + col + " → selectable = N (cannot be used in source/select)");
                        }
                    }

                    // FILTER usage requires filterable=Y
                    if (usageType.getOrDefault(table + "|" + col, Set.of()).contains("FILTER")) {
                        if (!"Y".equalsIgnoreCase(allowed.getFilterable())) {
                            errors.add(table + "." + col + " → filterable = N (cannot be used in filter)");
                        }
                    }

                    // Check aggregate functions
                    Set<String> reqAgg = requestedAggs.getOrDefault(table + "|" + col, Set.of());
                    if (!reqAgg.isEmpty()) {
                        Set<String> allowedAggs = Arrays.stream(
                                        Optional.ofNullable(allowed.getAggFuncs()).orElse("").split(","))
                                .map(String::trim).map(String::toUpperCase)
                                .filter(s -> !s.isEmpty())
                                .collect(Collectors.toSet());

                        for (String a : reqAgg) {
                            if (!allowedAggs.contains(a.toUpperCase())) {
                                errors.add("Aggregate " + a + " not allowed for " + table + "." + col);
                            }
                        }
                    }
                }
            }

            if (!errors.isEmpty()) {
                throw new WhitelistValidationException(ResponseMessages.VALIDATION_FAILED + errors);
            }

            log.info("Whitelist validation successful for tables {} and columns {}", tables, allReferencedCols);

        } catch (WhitelistValidationException ex) {
            throw ex;

        } catch (Exception ex) {
            log.error("Whitelist validator exception", ex);
            throw new WhitelistValidationException(ResponseMessages.INTERNAL_ERROR);
        }
    }

    // ===================================================
    // JSON SCANNING LOGIC
    // ===================================================

    private void extractDbReferences(
            JsonNode root,
            Set<String> tables,
            Map<String, Set<String>> tableColumns,
            Map<String, Set<String>> usage,
            Map<String, Set<String>> aggMap
    ) {
        extractFromReportData(root, tables, tableColumns, usage, aggMap);
        extractFromFilterRules(root.path("filterRules"), tables, tableColumns, usage);
        if (root.path("variants").isArray()) {
            for (JsonNode v : root.path("variants")) {
                extractFromFilterRules(v.path("filterRules"), tables, tableColumns, usage);
            }
        }
    }

    private void extractFromReportData(JsonNode root,
                                       Set<String> tables,
                                       Map<String, Set<String>> tableColumns,
                                       Map<String, Set<String>> usage,
                                       Map<String, Set<String>> aggMap) {

        JsonNode reportData = root.path("reportData");
        if (reportData.isMissingNode()) return;

        // ------------------------
        // Scan rows -> cells -> source
        // ------------------------
        JsonNode rows = reportData.path("rows");
        if (rows.isArray()) {
            for (JsonNode row : rows) {
                JsonNode cells = row.path("cells");
                if (cells.isArray()) {
                    for (JsonNode cell : cells) {
                        JsonNode source = cell.path("source");
                        if (!source.isMissingNode() && !source.isEmpty()) {
                            String table = text(source, "table");
                            String col = text(source, "column");

                            if (table != null) {
                                tables.add(table.toUpperCase());
                                tableColumns.computeIfAbsent(table.toUpperCase(), k -> new HashSet<>());
                            }
                            if (table != null && col != null) {
                                tableColumns.get(table.toUpperCase()).add(col.toUpperCase());
                                usage.computeIfAbsent(table.toUpperCase() + "|" + col.toUpperCase(), k -> new HashSet<>())
                                        .add("SOURCE");
                            }

                            String agg = text(source, "agg");
                            if (agg != null && table != null && col != null) {
                                aggMap.computeIfAbsent(table.toUpperCase() + "|" + col.toUpperCase(), k -> new HashSet<>())
                                        .add(agg.toUpperCase());
                            }
                        }
                    }
                }

                // dynamicConfig
                JsonNode dynamic = row.path("dynamicConfig");
                if (!dynamic.isMissingNode()) {
                    String dtTable = text(dynamic, "table");
                    if (dtTable != null) {
                        tables.add(dtTable.toUpperCase());
                        tableColumns.computeIfAbsent(dtTable.toUpperCase(), k -> new HashSet<>());
                    }

                    JsonNode select = dynamic.path("select");
                    if (select.isArray() && dtTable != null) {
                        for (JsonNode col : select) {
                            String c = col.asText();
                            tableColumns.get(dtTable.toUpperCase()).add(c.toUpperCase());
                            usage.computeIfAbsent(dtTable.toUpperCase() + "|" + c.toUpperCase(), k -> new HashSet<>())
                                    .add("SELECT");
                        }
                    }
                }
            }
        }
    }

    private void extractFromFilterRules(JsonNode filterRules,
                                        Set<String> tables,
                                        Map<String, Set<String>> tableColumns,
                                        Map<String, Set<String>> usage) {

        if (!filterRules.isArray()) return;

        for (JsonNode fr : filterRules) {
            String dbCol = text(fr, "dbColumn");

            if (dbCol == null) continue;

            if (dbCol.contains(".")) {
                String[] parts = dbCol.split("\\.");
                String table = parts[0];
                String col = parts[1];

                tables.add(table.toUpperCase());
                tableColumns.computeIfAbsent(table.toUpperCase(), k -> new HashSet<>()).add(col.toUpperCase());
                usage.computeIfAbsent(table.toUpperCase() + "|" + col.toUpperCase(), k -> new HashSet<>())
                        .add("FILTER");

            } else {
                // column without table → wildcard filter
                usage.computeIfAbsent("*|" + dbCol.toUpperCase(), k -> new HashSet<>()).add("FILTER");
            }
        }
    }

    private String text(JsonNode n, String field) {
        JsonNode v = n.path(field);
        return v.isMissingNode() || v.isNull() ? null : v.asText();
    }
}